"use client";
import React, { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import ApplyClubModal from "@/components/ApplyClubModal";
import {
  Users,
  Zap,
  Calendar,
  Star,
  CheckCircle2,
  Clock,
  ArrowRight,
  Shield,
  Megaphone,
  Briefcase,
  Share2,
  Bookmark,
  Award,
  ChevronRight,
  Mail,
  MapPin,
} from "lucide-react";

export default function ClubDetailPage() {
  const params = useParams();
  const clubId = params.id;
  const { currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState("recruitment");
  const [isFollowing, setIsFollowing] = useState(false);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [selectedRoleForApply, setSelectedRoleForApply] = useState(null);
  const [toastMessage, setToastMessage] = useState("");

  const [club, setClub] = useState({
    id: clubId || "club-1",
    name: "Technical Club",
    tagline: "Build. Learn. Innovate.",
    tags: ["Technology", "Workshops", "Hackathons"],
    members: 450,
    activeMembers: 120,
    eventsConducted: 15,
    rating: 4.5,
    banner: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1600&auto=format&fit=crop&q=80",
    description:
      "The premier software development and technology organization on campus. We build production-ready projects, conduct hands-on workshops in web & AI, and organize campus hackathons.",
  });

  const [currentRecruitments, setCurrentRecruitments] = useState([
    {
      id: "rec-core",
      title: "Core Team Recruitment",
      tracks: "Web Dev | Design | Content | Event Management",
      status: "Open",
      daysRemaining: "Ends in 5 days",
      icon: Megaphone,
      iconBg: "bg-blue-100 text-blue-600",
    },
    {
      id: "rec-gen",
      title: "General Member",
      tracks: "Open for all branches",
      status: "Open",
      daysRemaining: "Ends in 10 days",
      icon: Users,
      iconBg: "bg-rose-100 text-rose-600",
    },
  ]);

  const [pastRecruitments] = useState([
    {
      id: "rec-past-1",
      title: "General Member (Aug 2024)",
      status: "Closed",
      date: "Fall 2024 Cycle",
      icon: Shield,
    },
  ]);

  useEffect(() => {
    if (!clubId) return;
    const fetchClub = async () => {
      try {
        const res = await fetch(`/api/clubs/${clubId}`);
        const data = await res.json();
        if (data.success && data.club) {
          const c = data.club;
          setClub({
            id: c.id,
            name: c.name,
            tagline: c.tagLine || "Discover. Join. Contribute.",
            tags: [c.category, "Campus Organization", "Active Chapter"],
            members: c.memberCount || 150,
            activeMembers: Math.round((c.memberCount || 150) * 0.65),
            eventsConducted: data.events?.length || 8,
            rating: 4.8,
            banner: c.banner || "https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1600&auto=format&fit=crop&q=80",
            description: c.description || c.tagLine,
            contactEmail: c.contactEmail,
            meetingSchedule: c.meetingSchedule,
            presidentName: c.presidentName,
          });

          if (c.recruitmentOpen) {
            setCurrentRecruitments([
              {
                id: `rec-${c.id}-core`,
                title: `${c.category} Core Team & Leads`,
                tracks: "Operations | Events | Creative | Outreach",
                status: "Open",
                daysRemaining: c.recruitmentDeadline ? `Ends ${c.recruitmentDeadline}` : "Open Now",
                icon: Megaphone,
                iconBg: "bg-blue-100 text-blue-600",
              },
              {
                id: `rec-${c.id}-gen`,
                title: "General Member Intake",
                tracks: "Open for all branches and semesters",
                status: "Open",
                daysRemaining: "Open this term",
                icon: Users,
                iconBg: "bg-rose-100 text-rose-600",
              },
            ]);
          } else {
            setCurrentRecruitments([]);
          }
        }
      } catch (err) {
        console.error("Failed to load club details:", err);
      }
    };
    fetchClub();
  }, [clubId]);

  const handleApplySuccess = () => {
    setToastMessage("Application submitted! Club leads will review your portfolio.");
    setTimeout(() => setToastMessage(""), 4500);
  };

  const handleOpenModal = (roleTitle) => {
    setSelectedRoleForApply(roleTitle);
    setIsApplyModalOpen(true);
  };

  return (
    <div className="bg-[#EDF1F7] dark:bg-[#121316] text-slate-900 dark:text-slate-100 min-h-screen pb-20 pt-4 transition-colors duration-300">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top">
          <CheckCircle2 className="h-4 w-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-6">
        {/* Breadcrumb Navigation */}
        <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
          <Link href="/dashboard/student" className="hover:text-blue-600 dark:hover:text-[#D2F863]">
            Student Dashboard
          </Link>
          <ChevronRight className="h-3 w-3 text-slate-400 dark:text-slate-600" />
          <Link href="/clubs" className="hover:text-blue-600 dark:hover:text-[#D2F863]">
            Clubs
          </Link>
          <ChevronRight className="h-3 w-3 text-slate-400 dark:text-slate-600" />
          <span className="text-slate-800 dark:text-white font-semibold">{club.name}</span>
        </div>

        {/* HERO CARD WITH COVER BANNER */}
        <section className="bg-white dark:bg-[#14151B] rounded-3xl border border-slate-200/90 dark:border-white/10 overflow-hidden shadow-xs transition-colors duration-300">
          {/* Cover Photo */}
          <div className="relative h-48 sm:h-64 w-full overflow-hidden bg-slate-900">
            <img
              src={club.banner}
              alt={club.name}
              className="w-full h-full object-cover opacity-90"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
          </div>

          {/* Profile Header Details */}
          <div className="px-6 sm:px-8 pb-6 sm:pb-8 pt-0 relative">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 -mt-12 sm:-mt-14 mb-6">
              {/* Avatar + Title */}
              <div className="flex items-end gap-4">
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-3xl bg-blue-600 border-4 border-white dark:border-[#14151B] shadow-md flex items-center justify-center text-white shrink-0">
                  <Zap className="h-12 w-12" />
                </div>
                <div className="space-y-1">
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight">
                    {club.name}
                  </h1>
                  <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">
                    {club.tagline}
                  </p>
                  {/* Category Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {club.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-[#D2F863] border border-blue-200/60 dark:border-blue-900/50"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2.5 self-start sm:self-auto shrink-0">
                <button
                  type="button"
                  onClick={() => handleOpenModal("General Member / Core")}
                  style={{ backgroundColor: "#F37021", color: "#FFFFFF" }}
                  className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition-all shadow-sm active:scale-95 flex items-center gap-2 cursor-pointer"
                >
                  <Briefcase className="h-4 w-4" />
                  <span>Apply for Recruitment</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsFollowing(!isFollowing)}
                  className={`px-4 py-2.5 rounded-xl border text-xs font-bold transition-colors ${
                    isFollowing
                      ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                      : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                  }`}
                >
                  {isFollowing ? "✓ Following" : "Follow Club"}
                </button>
              </div>
            </div>

            {/* Key Statistics Bar */}
            <div className="pt-5 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center sm:text-left">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                  <Users className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-lg font-bold text-slate-900 leading-none">
                    {club.members}
                  </div>
                  <div className="text-xs text-slate-500 font-medium mt-1">Members</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                  <Zap className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-lg font-bold text-slate-900 leading-none">
                    {club.activeMembers}
                  </div>
                  <div className="text-xs text-slate-500 font-medium mt-1">Active Members</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                  <Calendar className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-lg font-bold text-slate-900 leading-none">
                    {club.eventsConducted}
                  </div>
                  <div className="text-xs text-slate-500 font-medium mt-1">Events Conducted</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-500 flex items-center justify-center shrink-0">
                  <Star className="h-5 w-5 fill-amber-400 text-amber-400" />
                </div>
                <div>
                  <div className="text-lg font-bold text-slate-900 leading-none flex items-center gap-1">
                    <span>{club.rating}</span>
                    <span className="text-xs text-amber-500 font-normal">/ 5.0</span>
                  </div>
                  <div className="text-xs text-slate-500 font-medium mt-1">Club Rating</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* TABS NAVIGATION */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
          {["Overview", "Members", "Events", "Recruitment", "Achievements"].map((tab) => {
            const key = tab.toLowerCase();
            const isActive = activeTab === key;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(key)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  isActive
                    ? "bg-blue-600 text-white shadow-xs"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* TAB CONTENTS */}
        {activeTab === "recruitment" && (
          <div className="space-y-6">
            {/* Current Recruitments */}
            <div className="space-y-3.5">
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Current Recruitments
              </h2>

              {currentRecruitments.map((rec) => {
                const IconComp = rec.icon;
                return (
                  <div
                    key={rec.id}
                    className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${rec.iconBg}`}>
                        <IconComp className="h-6 w-6" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2.5">
                          <h3 className="text-sm font-bold text-slate-900">
                            {rec.title}
                          </h3>
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-600 border border-emerald-200">
                            {rec.status}
                          </span>
                          <span className="text-xs text-slate-500 font-medium">
                            {rec.daysRemaining}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 font-medium">
                          {rec.tracks}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleOpenModal(rec.title)}
                      style={{ backgroundColor: "#F37021", color: "#FFFFFF" }}
                      className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition-all shadow-xs active:scale-95 flex items-center gap-1.5 self-start sm:self-auto shrink-0 cursor-pointer"
                    >
                      <span>Apply Now</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Past Recruitments */}
            <div className="space-y-3.5 pt-4">
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Past Recruitments
              </h2>

              {pastRecruitments.map((rec) => {
                const IconComp = rec.icon;
                return (
                  <div
                    key={rec.id}
                    className="p-4 sm:p-5 rounded-2xl bg-white border border-slate-200/70 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4 opacity-80"
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-500 flex items-center justify-center shrink-0">
                        <IconComp className="h-5 w-5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-slate-700">
                            {rec.title}
                          </h3>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-600 border border-slate-200">
                            {rec.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{rec.date}</p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setToastMessage("Archived recruitment record viewed.");
                        setTimeout(() => setToastMessage(""), 2000);
                      }}
                      className="px-4 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 text-xs font-semibold border border-slate-200 transition-colors self-start sm:self-auto"
                    >
                      View Details
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === "overview" && (
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-[#14151B] border border-slate-200/90 dark:border-white/10 shadow-xs space-y-4 transition-colors">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">About the Club</h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed max-w-3xl">
              {club.description}
            </p>
            <div className="pt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-blue-600 dark:text-[#D2F863]" />
                <span>Weekly Meetings: Wednesdays @ 5:30 PM (Engineering Hall 302)</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-blue-600 dark:text-[#D2F863]" />
                <span>Contact: tech-lead@campus.edu</span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "members" && (
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Leadership & Active Roster</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <span className="text-[11px] font-bold text-blue-600 uppercase">Club Lead</span>
                <h4 className="text-sm font-bold text-slate-900 mt-1">Rahul Sharma</h4>
                <p className="text-xs text-slate-500">Computer Science · Final Year</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <span className="text-[11px] font-bold text-purple-600 uppercase">Vice President</span>
                <h4 className="text-sm font-bold text-slate-900 mt-1">Priya Singh</h4>
                <p className="text-xs text-slate-500">Information Systems · 3rd Year</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
                <span className="text-[11px] font-bold text-emerald-600 uppercase">Faculty Advisor</span>
                <h4 className="text-sm font-bold text-slate-900 mt-1">Dr. S. Verma</h4>
                <p className="text-xs text-slate-500">Dept of Computer Engineering</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "events" && (
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Conducted & Upcoming Events</h2>
            <div className="space-y-3">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Annual HackPulse 36h Hackathon</h4>
                  <p className="text-xs text-slate-500">120+ participants · Completed & Dean Verified</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-700">
                  Verified
                </span>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900">AI Agents & LLM Architecture Hands-on</h4>
                  <p className="text-xs text-slate-500">48 Attendees · Eng 302</p>
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-700">
                  Completed
                </span>
              </div>
            </div>
          </div>
        )}

        {activeTab === "achievements" && (
          <div className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-4">
            <h2 className="text-base font-bold text-slate-900">Verified Badges & Dean Standing</h2>
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80">
              <Award className="h-8 w-8 text-amber-500 shrink-0" />
              <div>
                <h4 className="text-sm font-bold text-slate-900">Tier 1 Gold Standing</h4>
                <p className="text-xs text-slate-600">
                  Consistently maintained over 90% attendance audit score and timely budget reconciliations.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Interactive Application Modal */}
      <ApplyClubModal
        club={club}
        initialRole={selectedRoleForApply}
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
        onSuccess={handleApplySuccess}
      />
    </div>
  );
}
