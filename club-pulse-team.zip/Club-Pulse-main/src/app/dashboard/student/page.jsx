"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import ApplyClubModal from "@/components/ApplyClubModal";
import {
  Users,
  Compass,
  Calendar,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  Clock,
  Award,
  Zap,
  Camera,
  Music,
  Trophy,
  Megaphone,
  Briefcase,
  Layers,
  ChevronRight,
} from "lucide-react";

export default function StudentDashboardPage() {
  const { currentUser } = useAuth();
  const [selectedClubForModal, setSelectedClubForModal] = useState(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  const [popularClubs] = useState([
    {
      id: "club-1",
      name: "Technical Club",
      members: "450 members",
      tagline: "Build. Learn. Innovate.",
      icon: Zap,
      iconBg: "bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400",
      borderHover: "hover:border-orange-300 dark:hover:border-white/20",
    },
    {
      id: "club-3",
      name: "Symphony Cultural Club",
      members: "320 members",
      tagline: "Art. Music. Expression.",
      icon: Music,
      iconBg: "bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400",
      borderHover: "hover:border-orange-300 dark:hover:border-white/20",
    },
    {
      id: "club-6",
      name: "University Football & Sports",
      members: "500 members",
      tagline: "Play. Compete. Grow.",
      icon: Trophy,
      iconBg: "bg-amber-100 text-amber-600 dark:bg-amber-950/40 dark:text-amber-400",
      borderHover: "hover:border-orange-300 dark:hover:border-white/20",
    },
    {
      id: "club-10",
      name: "ShutterSpeed Photography",
      members: "260 members",
      tagline: "Capture. Share. Inspire.",
      icon: Camera,
      iconBg: "bg-emerald-100 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400",
      borderHover: "hover:border-orange-300 dark:hover:border-white/20",
    },
    {
      id: "club-12",
      name: "GreenCampus Eco Society",
      members: "275 members",
      tagline: "Sustain. Conserve. Impact.",
      icon: Compass,
      iconBg: "bg-teal-100 text-teal-600 dark:bg-teal-950/40 dark:text-teal-400",
      borderHover: "hover:border-orange-300 dark:hover:border-white/20",
    },
    {
      id: "club-14",
      name: "Growth Pulse Marketing",
      members: "190 members",
      tagline: "Brand. Market. Amplify.",
      icon: Megaphone,
      iconBg: "bg-purple-100 text-purple-600 dark:bg-purple-950/40 dark:text-purple-400",
      borderHover: "hover:border-orange-300 dark:hover:border-white/20",
    },
  ]);

  const [recruitments, setRecruitments] = useState([
    {
      id: "rec-1",
      clubName: "Technical Club",
      clubId: "club-1",
      role: "Core Team Recruitment",
      tags: "Web Dev | Design | Content | Event Management",
      daysLeft: "Ends in 5 days",
      status: "Open",
      icon: Zap,
      iconBg: "bg-blue-100 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400",
    },
    {
      id: "rec-2",
      clubName: "Marketing Club",
      clubId: "club-6",
      role: "General Member",
      tags: "Social Media, PR & Sponsorships",
      daysLeft: "Ends in 7 days",
      status: "Open",
      icon: Megaphone,
      iconBg: "bg-rose-100 text-rose-600 dark:bg-rose-950/40 dark:text-rose-400",
    },
  ]);

  const [myActivity, setMyActivity] = useState({
    joinedClubs: 2,
    pendingApplications: 1,
    eventsParticipated: 3,
    totalContributions: 8,
  });

  const [selectedRoleForModal, setSelectedRoleForModal] = useState("");

  const handleOpenApply = (club, role) => {
    setSelectedClubForModal(club);
    setSelectedRoleForModal(role || "");
    setIsApplyModalOpen(true);
  };

  const handleApplySuccess = () => {
    setMyActivity((prev) => ({
      ...prev,
      pendingApplications: prev.pendingApplications + 1,
    }));
    setToastMessage("Application submitted successfully! Leadership will review soon.");
    setTimeout(() => setToastMessage(""), 4000);
  };

  return (
    <div className="bg-[#EDF1F7] dark:bg-[#121316] text-slate-900 dark:text-slate-100 min-h-screen pb-16 pt-6 transition-colors duration-300">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top">
          <CheckCircle2 className="h-4 w-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        {/* 1. WELCOME HERO BANNER */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-orange-50/70 via-amber-50/40 to-blue-50/30 dark:from-[#18191E] dark:via-[#1D1E25] dark:to-[#18191E] border border-orange-100/70 dark:border-white/10 p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
            {/* Left Welcome Copy */}
            <div className="max-w-xl">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                Welcome back, {currentUser?.name || "Ayush"}! 👋
              </h1>
              <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 font-normal leading-relaxed">
                Find your community, grow your skills, and make an impact.
              </p>

              {/* 4 Stat Badges / Pills */}
              <div className="mt-6 flex flex-wrap items-center gap-2.5">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-blue-100/80 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 text-xs font-semibold shadow-2xs border border-blue-200/60 dark:border-blue-900/40">
                  <span className="w-2 h-2 rounded-full bg-blue-600" />
                  <span>12 Clubs Available</span>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-orange-100/80 dark:bg-orange-950/40 text-orange-800 dark:text-orange-300 text-xs font-semibold shadow-2xs border border-orange-200/60 dark:border-orange-900/40">
                  <span className="w-2 h-2 rounded-full bg-[#F37021]" />
                  <span>5 Recruitments Open</span>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-100/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 text-xs font-semibold shadow-2xs border border-emerald-200/60 dark:border-emerald-900/40">
                  <span className="w-2 h-2 rounded-full bg-emerald-600" />
                  <span>{myActivity.pendingApplications} Applications Submitted</span>
                </div>
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-100/80 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-xs font-semibold shadow-2xs border border-amber-200/60 dark:border-amber-900/40">
                  <span className="w-2 h-2 rounded-full bg-amber-600" />
                  <span>6 Events Coming Up</span>
                </div>
              </div>
            </div>

            {/* Right Friendly Illustration Graphic */}
            <div className="shrink-0 flex items-center justify-center">
              <div className="w-48 sm:w-56 h-32 sm:h-36 rounded-2xl bg-gradient-to-tr from-orange-500/10 via-amber-500/15 to-blue-500/10 dark:from-white/5 dark:via-white/10 dark:to-white/5 border border-orange-200/50 dark:border-white/10 flex flex-col items-center justify-center p-4 text-center relative overflow-hidden group">
                <div className="flex -space-x-2 mb-2">
                  <div className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-800 bg-[#F37021] text-white flex items-center justify-center text-xs font-bold shadow-sm">
                    👨‍💻
                  </div>
                  <div className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-800 bg-emerald-500 text-white flex items-center justify-center text-xs font-bold shadow-sm">
                    👩‍🎨
                  </div>
                  <div className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-800 bg-purple-500 text-white flex items-center justify-center text-xs font-bold shadow-sm">
                    🚀
                  </div>
                </div>
                <span className="text-xs font-bold text-slate-800 dark:text-white">48+ Active Chapters</span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">Campus Network</span>
              </div>
            </div>
          </div>
        </section>

        {/* 2. POPULAR CLUBS */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white tracking-tight">
              Popular Clubs
            </h2>
            <Link
              href="/clubs"
              className="text-xs font-bold text-[#F37021] dark:text-orange-400 hover:underline inline-flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-4">
            {popularClubs.map((club) => {
              const IconComponent = club.icon;
              return (
                <div
                  key={club.id}
                  className={`bg-white dark:bg-[#18191E] rounded-2xl border border-slate-200/80 dark:border-white/10 p-5 flex flex-col justify-between transition-all duration-200 hover:shadow-md ${club.borderHover}`}
                >
                  <div>
                    <div className="flex items-center gap-3 mb-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${club.iconBg}`}>
                        <IconComponent className="h-5 w-5" />
                      </div>
                      <div>
                        <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                          {club.name}
                        </h3>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                          {club.members}
                        </p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {club.tagline}
                    </p>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-100 dark:border-white/10">
                    <Link
                      href={`/clubs/${club.id}`}
                      className="w-full py-2 rounded-xl bg-slate-50 dark:bg-white/5 hover:bg-orange-50 dark:hover:bg-white/10 text-slate-700 dark:text-slate-200 hover:text-[#F37021] dark:hover:text-orange-400 text-xs font-bold transition-colors border border-slate-200/60 dark:border-white/10 flex items-center justify-center gap-1"
                    >
                      <span>View Club</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 3. TWO-COLUMN SPLIT: Upcoming Recruitments & My Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT COLUMN: Upcoming Recruitments (7 cols) */}
          <section id="recruitments" className="lg:col-span-7 space-y-4 scroll-mt-24">
            <div className="flex items-center justify-between">
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                Upcoming Recruitments
              </h2>
              <Link
                href="/recruitment"
                className="text-xs font-bold text-[#F37021] dark:text-orange-400 hover:underline inline-flex items-center gap-1"
              >
                <span>View All</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            <div className="space-y-3.5">
              {recruitments.map((rec) => {
                const IconComp = rec.icon;
                return (
                  <div
                    key={rec.id}
                    className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-[#18191E] border border-slate-200/80 dark:border-white/10 shadow-xs hover:border-orange-300 dark:hover:border-white/20 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-start gap-3.5">
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${rec.iconBg}`}>
                        <IconComp className="h-5 w-5" />
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                            {rec.clubName}
                          </h3>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/40">
                            {rec.status}
                          </span>
                        </div>
                        <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          {rec.role}
                        </p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">
                          {rec.daysLeft}
                        </p>
                      </div>
                    </div>

                    {/* Prominent Orange Apply Button */}
                    <button
                      type="button"
                      onClick={() => handleOpenApply({ id: rec.clubId, name: rec.clubName }, rec.role)}
                      style={{ backgroundColor: "#F37021", color: "#FFFFFF" }}
                      className="shrink-0 self-start sm:self-center px-4 py-2 rounded-xl bg-[#F37021] hover:bg-[#EA580C] text-white text-xs font-bold transition-all shadow-xs active:scale-95 flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Apply Now</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </section>

          {/* RIGHT COLUMN: My Activity (5 cols) */}
          <section className="lg:col-span-5 space-y-4" id="my-activity">
            <div className="flex items-center justify-between">
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                My Activity
              </h2>
              <Link
                href="/activity"
                className="text-xs font-bold text-[#F37021] dark:text-orange-400 hover:underline inline-flex items-center gap-1"
              >
                <span>View Full Record</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-[#18191E] border border-slate-200/80 dark:border-white/10 shadow-xs space-y-4">
              <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-orange-50 dark:bg-orange-950/40 text-[#F37021] dark:text-orange-400 flex items-center justify-center">
                    <Users className="h-4 w-4" />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Joined Clubs</span>
                </div>
                <span className="text-sm font-extrabold text-slate-900 dark:text-white font-mono">
                  {myActivity.joinedClubs}
                </span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-300 flex items-center justify-center">
                    <Briefcase className="h-4 w-4" />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Pending Applications</span>
                </div>
                <span className="text-sm font-extrabold text-slate-900 dark:text-white font-mono">
                  {myActivity.pendingApplications}
                </span>
              </div>

              <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-white/10">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-300 flex items-center justify-center">
                    <Calendar className="h-4 w-4" />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Events Participated</span>
                </div>
                <span className="text-sm font-extrabold text-slate-900 dark:text-white font-mono">
                  {myActivity.eventsParticipated}
                </span>
              </div>

              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-300 flex items-center justify-center">
                    <CheckCircle2 className="h-4 w-4" />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">Total Contributions</span>
                </div>
                <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400 font-mono">
                  {myActivity.totalContributions}
                </span>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-white/10">
                <Link
                  href="/activity"
                  className="w-full py-2.5 rounded-xl bg-orange-50 dark:bg-white/5 hover:bg-orange-100 dark:hover:bg-white/10 text-[#F37021] dark:text-orange-400 text-xs font-bold transition-colors flex items-center justify-center gap-1.5 border border-orange-200/50 dark:border-white/10"
                >
                  <span>View Full Activity & Proofs</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          </section>
        </div>
      </div>

      {/* Interactive Application Modal */}
      <ApplyClubModal
        club={selectedClubForModal}
        initialRole={selectedRoleForModal}
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
        onSuccess={handleApplySuccess}
      />
    </div>
  );
}
