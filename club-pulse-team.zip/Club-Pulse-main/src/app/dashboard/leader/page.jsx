"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import {
  AlertTriangle,
  Zap,
  Users,
  TrendingUp,
  CheckSquare,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  Send,
  Plus,
} from "lucide-react";

export default function LeaderDashboard() {
  const { currentUser } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [rebalanced, setRebalanced] = useState(false);
  const [toastMessage, setToastMessage] = useState("");

  // Officer workload state
  const [workload, setWorkload] = useState([
    { name: "Sarah Chen (President)", role: "Operations & Budget", pct: 42, color: "bg-amber-400" },
    { name: "Michael Torres (VP)", role: "Hackathon Lead", pct: 32, color: "bg-neutral-400" },
    { name: "Maya Lin (Tech Lead)", role: "Curriculum & Infra", pct: 16, color: "bg-neutral-600" },
    { name: "Liam Zhang (Design)", role: "Marketing & Assets", pct: 10, color: "bg-neutral-700" },
  ]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/tasks");
      const data = await res.json();
      if (data.success) setTasks(data.tasks);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handle1ClickRebalance = () => {
    setRebalanced(true);
    // Smoothly re-distribute loads
    setWorkload([
      { name: "Sarah Chen (President)", role: "Operations & Budget", pct: 28, color: "bg-amber-400" },
      { name: "Michael Torres (VP)", role: "Hackathon Lead", pct: 26, color: "bg-neutral-400" },
      { name: "Maya Lin (Tech Lead)", role: "Curriculum & Infra", pct: 26, color: "bg-neutral-500" },
      { name: "Liam Zhang (Design)", role: "Marketing & Assets", pct: 20, color: "bg-neutral-600" },
    ]);
    setToastMessage("Rebalanced: 12 hrs/wk shifted across Maya Lin & Liam Zhang!");
    setTimeout(() => setToastMessage(""), 4500);
  };

  return (
    <div className="bg-[#0A0A0B] text-neutral-100 min-h-screen py-8 px-4 sm:px-6">
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-amber-400 text-black px-4 py-2 rounded-lg text-xs font-semibold shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top">
          <Zap className="h-4 w-4 fill-black" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto space-y-8">
        {/* Top Header */}
        <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#27272A]">
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-2xl font-semibold tracking-tight text-white">
                Association for Computing Machinery
              </h1>
              <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Active Chapter
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Executive health, capacity load telemetry, and supportive community retention.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <Link
              href="/transparency"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium text-neutral-300 bg-[#141416] hover:bg-[#1C1C20] border border-[#27272A] transition-all"
            >
              Export Audit Dossier
            </Link>
            <button
              type="button"
              onClick={handle1ClickRebalance}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold text-black bg-amber-400 hover:bg-amber-300 transition-all shadow-sm"
            >
              <Zap className="h-3.5 w-3.5 fill-black" />
              <span>1-Click Rebalance</span>
            </button>
          </div>
        </section>

        {/* 1. Workload Hazard / Burnout Alert Card */}
        <section
          className={`relative overflow-hidden rounded-xl border p-5 sm:p-6 transition-all ${
            rebalanced
              ? "border-emerald-500/30 bg-gradient-to-r from-emerald-950/20 via-[#141416] to-[#141416]"
              : "border-rose-500/20 bg-gradient-to-r from-rose-950/25 via-[#141416] to-amber-950/15"
          }`}
        >
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="flex items-start gap-4">
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                  rebalanced
                    ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                    : "bg-rose-500/10 border border-rose-500/20 text-rose-400"
                }`}
              >
                {rebalanced ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <AlertTriangle className="h-5 w-5" />
                )}
              </div>
              <div className="space-y-1.5 max-w-2xl">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[11px] font-mono uppercase tracking-wider font-medium ${
                      rebalanced ? "text-emerald-400" : "text-rose-400"
                    }`}
                  >
                    {rebalanced ? "Workload Harmonized" : "Workload Hazard Alert"}
                  </span>
                  <span className="text-neutral-600 text-xs">•</span>
                  <span className="text-xs text-neutral-400 font-mono">
                    {rebalanced ? "Stress Index 4.1 / 10 (Safe)" : "Stress Index 8.4 / 10 (Elevated)"}
                  </span>
                </div>
                <h2 className="text-base font-medium text-white tracking-tight">
                  {rebalanced
                    ? "Workload distributed evenly across all 4 officers. Capacity healthy."
                    : "Sarah Chen & Michael Torres carry 74% of ACM commitments this term."}
                </h2>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  {rebalanced
                    ? "12.0 hrs/wk of Hackathon operations shifted to Tech Lead Maya Lin & Design Lead Liam Zhang. Dean compliance preserved."
                    : "Automated rebalancing can shift 12.0 hrs/wk of Hackathon operations to Tech Lead Maya Lin, reducing leadership fatigue while maintaining Dean compliance."}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0 lg:pl-4">
              {!rebalanced ? (
                <button
                  type="button"
                  onClick={handle1ClickRebalance}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-amber-400 text-neutral-950 hover:bg-amber-300 shadow-md transition-all active:scale-[0.98]"
                >
                  <Zap className="h-4 w-4 fill-black" />
                  <span>1-Click Rebalance Tasks</span>
                </button>
              ) : (
                <span className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Balanced</span>
                </span>
              )}
            </div>
          </div>
        </section>

        {/* 2. Four Spacious KPI Cards */}
        <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="rounded-xl border border-[#27272A] bg-[#141416] p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span className="font-medium tracking-wide">Total Members</span>
              <Users className="h-4 w-4 text-neutral-400" />
            </div>
            <div className="my-3">
              <div className="text-3xl font-semibold tracking-tight text-white font-mono">64</div>
              <p className="text-xs text-neutral-400 mt-1">42 actively participating</p>
            </div>
            <div className="w-full bg-[#202024] h-1.5 rounded-full overflow-hidden">
              <div className="bg-amber-400 h-full rounded-full" style={{ width: "65.6%" }} />
            </div>
          </div>

          <div className="rounded-xl border border-[#27272A] bg-[#141416] p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span className="font-medium tracking-wide">Active Engagement</span>
              <TrendingUp className="h-4 w-4 text-neutral-400" />
            </div>
            <div className="my-3">
              <div className="text-3xl font-semibold tracking-tight text-white font-mono">65.6%</div>
              <p className="text-xs text-neutral-400 mt-1">Weekly active chapter ratio</p>
            </div>
            <div className="text-[11px] text-emerald-400 flex items-center gap-1 font-medium">
              <span>+4.2% from last cycle</span>
            </div>
          </div>

          <div className="rounded-xl border border-[#27272A] bg-[#141416] p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span className="font-medium tracking-wide">Tasks In Flight</span>
              <CheckSquare className="h-4 w-4 text-neutral-400" />
            </div>
            <div className="my-3">
              <div className="text-3xl font-semibold tracking-tight text-white font-mono">
                {tasks.length || 14}
              </div>
              <p className="text-xs text-neutral-400 mt-1">
                {rebalanced ? "0 bottleneck items" : "4 flagged bottleneck items"}
              </p>
            </div>
            <div className="text-[11px] text-neutral-400 flex items-center gap-1.5">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  rebalanced ? "bg-emerald-400" : "bg-rose-400"
                }`}
              />
              <span>{rebalanced ? "All assignments active" : "2 overdue approvals"}</span>
            </div>
          </div>

          <div className="rounded-xl border border-[#27272A] bg-[#141416] p-5 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-neutral-400">
              <span className="font-medium tracking-wide">Dean Trust Score</span>
              <ShieldCheck className="h-4 w-4 text-amber-400" />
            </div>
            <div className="my-3">
              <div className="text-3xl font-semibold tracking-tight text-white font-mono">
                92<span className="text-sm font-normal text-neutral-400"> / 100</span>
              </div>
              <p className="text-xs text-neutral-400 mt-1">Tier 1 Gold Chapter Status</p>
            </div>
            <div className="text-[11px] text-neutral-400 flex items-center justify-between">
              <span>Next audit Dec 18</span>
              <span className="text-amber-400 font-medium">Top 3%</span>
            </div>
          </div>
        </section>

        {/* 3. 2-Column Main Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Officer Workload Distribution (7 Cols) */}
          <section className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-semibold text-white tracking-tight">
                  Officer Workload Concentration
                </h2>
                <p className="text-xs text-neutral-400">
                  Weekly commitment hours across executive committee
                </p>
              </div>
              <span className="text-xs text-neutral-500 font-mono">
                {rebalanced ? "Balanced" : "74% Overload"}
              </span>
            </div>

            <div className="p-5 rounded-xl bg-[#141416] border border-[#27272A] space-y-4">
              {workload.map((officer, i) => (
                <div key={i} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <div>
                      <span className="font-medium text-white">{officer.name}</span>
                      <span className="text-neutral-500 text-[11px] ml-2">({officer.role})</span>
                    </div>
                    <span className="font-mono text-neutral-300 font-semibold">{officer.pct}%</span>
                  </div>
                  <div className="w-full bg-[#202024] h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${officer.color}`}
                      style={{ width: `${officer.pct}%` }}
                    />
                  </div>
                </div>
              ))}

              <div className="pt-3 border-t border-[#202024] flex items-center justify-between text-xs">
                <span className="text-neutral-400">
                  Target threshold: <strong className="text-neutral-200">≤ 30% per officer</strong>
                </span>
                {!rebalanced && (
                  <button
                    onClick={handle1ClickRebalance}
                    className="text-amber-400 hover:underline font-medium text-xs flex items-center gap-1"
                  >
                    <span>Auto-Delegate 4 tasks</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                )}
              </div>
            </div>
          </section>

          {/* Right Column: Ghost Member Check-ins & Exam Shields (5 Cols) */}
          <section className="lg:col-span-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-semibold text-white tracking-tight">
                  Ghost Member Support Telemetry
                </h2>
                <p className="text-xs text-neutral-400">
                  Non-culpable absence monitoring & exam shields
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="p-4 rounded-xl bg-[#141416] border border-[#27272A] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-neutral-800 border border-[#27272A] flex items-center justify-center text-xs font-semibold text-neutral-200">
                    AR
                  </div>
                  <div>
                    <h3 className="text-xs font-medium text-white">Alex Rivera</h3>
                    <p className="text-[11px] text-emerald-400">Exam Shield Active (Midterms)</p>
                  </div>
                </div>
                <span className="text-[11px] text-neutral-500 font-mono">Until Dec 4</span>
              </div>

              <div className="p-4 rounded-xl bg-[#141416] border border-[#27272A] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-neutral-800 border border-[#27272A] flex items-center justify-center text-xs font-semibold text-neutral-200">
                    DK
                  </div>
                  <div>
                    <h3 className="text-xs font-medium text-white">David Kim</h3>
                    <p className="text-[11px] text-amber-400">2 Inactive Meetings (Flagged)</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setToastMessage("Empathetic check-in message sent to David Kim!");
                    setTimeout(() => setToastMessage(""), 3500);
                  }}
                  className="px-2.5 py-1 rounded bg-[#202024] hover:bg-neutral-700 text-xs text-neutral-300 font-medium transition-colors"
                >
                  Send Check-in
                </button>
              </div>

              <div className="p-4 rounded-xl bg-[#141416] border border-[#27272A] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-neutral-800 border border-[#27272A] flex items-center justify-center text-xs font-semibold text-neutral-200">
                    EP
                  </div>
                  <div>
                    <h3 className="text-xs font-medium text-white">Elena Patel</h3>
                    <p className="text-[11px] text-neutral-400">Cap-stone Project Leave</p>
                  </div>
                </div>
                <span className="text-[11px] text-neutral-500 font-mono">Approved</span>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
