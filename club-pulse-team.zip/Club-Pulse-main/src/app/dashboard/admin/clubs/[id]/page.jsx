"use client";
import React, { useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  LayoutDashboard,
  Building2,
  TrendingUp,
  Calendar,
  FileCheck,
  FileText,
  UserCheck,
  Settings,
  LogOut,
  ArrowLeft,
  Search,
  ChevronDown,
  Shield,
  Zap,
  Users,
  GraduationCap,
  Award,
  AlertTriangle,
  UserX,
  UserPlus,
  Clock,
  CheckCircle2,
  Filter,
} from "lucide-react";

export default function AdminClubContributionsPage() {
  const params = useParams();
  const router = useRouter();
  const { switchPersona, logout } = useAuth();

  const [activeTab, setActiveTab] = useState("members");
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [toastMessage, setToastMessage] = useState("");

  const membersData = [
    {
      id: 1,
      name: "Rahul Sharma",
      role: "Lead",
      tasksCompleted: 25,
      eventsParticipated: 8,
      contributionScore: 95,
      status: "Highly Active",
      statusColor: "bg-emerald-50 text-emerald-700 border-emerald-200",
      barColor: "bg-emerald-500",
    },
    {
      id: 2,
      name: "Priya Singh",
      role: "Core Team",
      tasksCompleted: 18,
      eventsParticipated: 6,
      contributionScore: 85,
      status: "Active",
      statusColor: "bg-emerald-50 text-emerald-600 border-emerald-200",
      barColor: "bg-emerald-500",
    },
    {
      id: 3,
      name: "Arjun Mehta",
      role: "Core Team",
      tasksCompleted: 15,
      eventsParticipated: 5,
      contributionScore: 80,
      status: "Active",
      statusColor: "bg-emerald-50 text-emerald-600 border-emerald-200",
      barColor: "bg-emerald-500",
    },
    {
      id: 4,
      name: "Neha Gupta",
      role: "Member",
      tasksCompleted: 5,
      eventsParticipated: 2,
      contributionScore: 40,
      status: "Low",
      statusColor: "bg-amber-50 text-amber-700 border-amber-200",
      barColor: "bg-amber-500",
    },
    {
      id: 5,
      name: "Karan Verma",
      role: "Member",
      tasksCompleted: 1,
      eventsParticipated: 0,
      contributionScore: 20,
      status: "Inactive",
      statusColor: "bg-rose-50 text-rose-700 border-rose-200",
      barColor: "bg-rose-500",
    },
    {
      id: 6,
      name: "Riya Patel",
      role: "Member",
      tasksCompleted: 0,
      eventsParticipated: 1,
      contributionScore: 10,
      status: "Inactive",
      statusColor: "bg-rose-50 text-rose-700 border-rose-200",
      barColor: "bg-rose-500",
    },
    {
      id: 7,
      name: "Aditya Kumar",
      role: "Member",
      tasksCompleted: 3,
      eventsParticipated: 0,
      contributionScore: 35,
      status: "Low",
      statusColor: "bg-amber-50 text-amber-700 border-amber-200",
      barColor: "bg-amber-500",
    },
    {
      id: 8,
      name: "Sneha Jain",
      role: "Member",
      tasksCompleted: 1,
      eventsParticipated: 0,
      contributionScore: 10,
      status: "Inactive",
      statusColor: "bg-rose-50 text-rose-700 border-rose-200",
      barColor: "bg-rose-500",
    },
  ];

  const filteredMembers = membersData.filter((member) => {
    const matchesSearch = member.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRole =
      roleFilter === "all"
        ? true
        : roleFilter === "lead"
        ? member.role.includes("Lead")
        : roleFilter === "core"
        ? member.role.includes("Core")
        : roleFilter === "inactive"
        ? member.status === "Inactive"
        : true;
    return matchesSearch && matchesRole;
  });

  const handleSwitchToStudent = async () => {
    try {
      await switchPersona("student");
      router.push("/dashboard/student");
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen flex bg-[#F8FAFC]">
      {/* 1. DARK NAVY SIDEBAR */}
      <aside className="w-64 bg-[#0F172A] text-slate-300 flex flex-col justify-between shrink-0 border-r border-slate-800 hidden md:flex min-h-screen sticky top-0">
        <div>
          {/* Top Brand Logo */}
          <div className="p-6 pb-5 flex items-center gap-3 border-b border-slate-800/80">
            <div className="w-9 h-9 rounded-xl bg-[#F37021] flex items-center justify-center text-white shadow-md shadow-orange-500/20">
              <Shield className="h-5 w-5" />
            </div>
            <div>
              <span className="text-base font-extrabold text-white tracking-tight leading-none block">
                Club<span className="text-[#F37021]">Pulse</span>
              </span>
              <span className="text-[11px] font-medium text-slate-400 block mt-0.5">
                Admin Panel
              </span>
            </div>
          </div>

          {/* Nav Items */}
          <nav className="p-4 space-y-1 text-xs font-semibold">
            {[
              { label: "Dashboard", icon: LayoutDashboard, href: "/dashboard/admin?tab=overview" },
              { label: "All Clubs", icon: Building2, href: "/dashboard/admin?tab=clubs" },
              { label: "Contribution Analytics", icon: TrendingUp, href: "/dashboard/admin?tab=analytics" },
              { label: "Events & Impact", icon: Calendar, href: "/dashboard/admin?tab=events" },
              { label: "Recruitment Reviews", icon: FileCheck, href: "/dashboard/admin?tab=recruitment" },
              { label: "Reports", icon: FileText, href: "/dashboard/admin?tab=reports" },
              { label: "User Management", icon: UserCheck, href: "/dashboard/admin?tab=users" },
              { label: "Settings", icon: Settings, href: "/dashboard/admin?tab=settings" },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = item.label === "All Clubs" || item.label === "Contribution Analytics";
              return (
                <Link
                  key={item.label}
                  href={item.href}
                  className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all ${
                    isActive
                      ? "bg-blue-600 text-white font-bold shadow-xs shadow-blue-600/30"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>

        {/* Bottom Profile */}
        <div className="p-4 border-t border-slate-800/80 space-y-3">
          <button
            type="button"
            onClick={handleSwitchToStudent}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-blue-300 transition-colors"
          >
            <GraduationCap className="h-4 w-4" />
            <span>Switch to Student View</span>
          </button>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-blue-900/60 border border-blue-400/30 flex items-center justify-center text-xs font-bold text-blue-200 overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
                  alt="Dr. Mehta"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-xs font-bold text-white leading-tight">Dr. Mehta</p>
                <p className="text-[10px] text-slate-400 font-medium">Dean / Admin</p>
              </div>
            </div>

            <button
              onClick={() => {
                logout();
                router.push("/");
              }}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
              title="Logout"
            >
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* 2. MAIN CANVAS */}
      <main className="flex-1 p-6 sm:p-8 lg:p-10 space-y-6 overflow-y-auto max-w-7xl">
        {/* Back Button */}
        <div>
          <Link
            href="/dashboard/admin"
            className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-blue-600 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Dashboard</span>
          </Link>
        </div>

        {/* CLUB HEADER CARD */}
        <section className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 rounded-2xl bg-[#F37021] flex items-center justify-center text-white shrink-0 shadow-md shadow-orange-500/20">
              <GraduationCap className="h-8 w-8" />
            </div>
            <div className="space-y-1">
              <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
                Technical Club
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Build. Learn. Innovate.
              </p>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {["Technology", "Workshops", "Hackathons"].map((t) => (
                  <span
                    key={t}
                    className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200/60"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right Faculty & Lead Details */}
          <div className="flex items-center gap-6 pt-4 md:pt-0 border-t md:border-t-0 border-slate-100 text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                Faculty Coordinator
              </span>
              <span className="font-extrabold text-slate-900 text-sm mt-0.5 block">
                Dr. S. Verma
              </span>
            </div>
            <div className="h-8 w-px bg-slate-200 hidden sm:block" />
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                Club Lead
              </span>
              <span className="font-extrabold text-slate-900 text-sm mt-0.5 block">
                Rahul Sharma
              </span>
            </div>
          </div>
        </section>

        {/* TABS */}
        <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
          {["Overview", "Members & Contributions", "Events & Impact", "Recruitment", "Documents"].map((tab) => {
            const isActive = tab === "Members & Contributions";
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  isActive
                    ? "bg-blue-600 text-white shadow-xs"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* 4 STAT METRIC CARDS */}
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                <Users className="h-5 w-5" />
              </div>
              <div>
                <span className="text-2xl font-extrabold text-slate-900 font-mono leading-none block">
                  450
                </span>
                <span className="text-xs text-slate-500 font-medium mt-1 block">
                  Total Members
                </span>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <Zap className="h-5 w-5" />
              </div>
              <div>
                <span className="text-2xl font-extrabold text-slate-900 font-mono leading-none block">
                  120
                </span>
                <span className="text-xs text-slate-500 font-medium mt-1 block">
                  Active Members (26%)
                </span>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0">
                <UserX className="h-5 w-5" />
              </div>
              <div>
                <span className="text-2xl font-extrabold text-rose-600 font-mono leading-none block">
                  320
                </span>
                <span className="text-xs text-slate-500 font-medium mt-1 block">
                  Inactive Members
                </span>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shrink-0">
                <Shield className="h-5 w-5" />
              </div>
              <div>
                <span className="text-2xl font-extrabold text-slate-900 font-mono leading-none block">
                  8
                </span>
                <span className="text-xs text-slate-500 font-medium mt-1 block">
                  Core Team Members
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* MEMBER CONTRIBUTIONS TABLE SECTION */}
        <section className="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
          {/* Table Header Bar */}
          <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Member Contributions
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Individual workload, event participation records, and activity status
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search member name..."
                  className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                />
              </div>

              {/* Filter */}
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-700 focus:outline-none cursor-pointer"
              >
                <option value="all">All Members</option>
                <option value="lead">Leadership</option>
                <option value="core">Core Team</option>
                <option value="inactive">Inactive Only</option>
              </select>
            </div>
          </div>

          {/* Data Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-5 w-12">#</th>
                  <th className="py-3 px-5">Name</th>
                  <th className="py-3 px-5">Role</th>
                  <th className="py-3 px-5 text-center">Tasks Completed</th>
                  <th className="py-3 px-5 text-center">Events Participated</th>
                  <th className="py-3 px-5 w-44">Contribution Score</th>
                  <th className="py-3 px-5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredMembers.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-5 font-mono text-slate-400 font-semibold">
                      {m.id}
                    </td>
                    <td className="py-3.5 px-5 font-bold text-slate-900">
                      {m.name}
                    </td>
                    <td className="py-3.5 px-5 text-slate-600 font-medium">
                      {m.role}
                    </td>
                    <td className="py-3.5 px-5 text-center font-mono font-bold text-slate-800">
                      {m.tasksCompleted}
                    </td>
                    <td className="py-3.5 px-5 text-center font-mono font-bold text-slate-800">
                      {m.eventsParticipated}
                    </td>
                    <td className="py-3.5 px-5">
                      <div className="flex items-center gap-3">
                        <div className="w-24 bg-slate-100 h-2 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full ${m.barColor}`}
                            style={{ width: `${m.contributionScore}%` }}
                          />
                        </div>
                        <span className="font-mono font-bold text-slate-800 text-[11px]">
                          {m.contributionScore}
                        </span>
                      </div>
                    </td>
                    <td className="py-3.5 px-5 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${m.statusColor}`}
                      >
                        {m.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between text-xs text-slate-400">
            <span>Showing {filteredMembers.length} of {membersData.length} records</span>
            <span className="font-semibold text-blue-600">320 inactive members flagged for Dean audit notice</span>
          </div>
        </section>
      </main>
    </div>
  );
}
