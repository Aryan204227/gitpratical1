"use client";
import React, { useState, useEffect, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import ThemeToggle from "@/components/ThemeToggle";
import {
  LayoutDashboard,
  Building2,
  TrendingUp,
  Calendar,
  FileCheck,
  FileText,
  UserCheck,
  Settings,
  LogOut,
  ChevronDown,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Briefcase,
  Users,
  GraduationCap,
  Shield,
  Activity,
  ChevronRight,
  Search,
  Download,
  Filter,
  UserX,
  FileDown,
  ExternalLink,
  Sliders,
  Bell,
  Trash2,
  Check,
  X,
  Eye,
  Plus,
  Sun,
  Moon,
  Heart,
} from "lucide-react";

const SLUG_TO_LABEL = {
  overview: "Dashboard",
  dashboard: "Dashboard",
  clubs: "All Clubs",
  "all-clubs": "All Clubs",
  analytics: "Contribution Analytics",
  "contribution-analytics": "Contribution Analytics",
  events: "Events & Impact",
  "events-and-impact": "Events & Impact",
  recruitment: "Recruitment Reviews",
  "recruitment-reviews": "Recruitment Reviews",
  reports: "Reports",
  users: "User Management",
  "user-management": "User Management",
  settings: "Settings",
};

const LABEL_TO_SLUG = {
  "Dashboard": "overview",
  "All Clubs": "clubs",
  "Contribution Analytics": "analytics",
  "Events & Impact": "events",
  "Recruitment Reviews": "recruitment",
  "Reports": "reports",
  "User Management": "users",
  "Settings": "settings",
};

function AdminDashboardContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { currentUser, isLoading, switchPersona, logout } = useAuth();
  const { theme, isDark, setTheme, toggleTheme } = useTheme();

  useEffect(() => {
    if (!isLoading) {
      if (!currentUser) {
        router.push("/login?redirect=/dashboard/admin");
      } else if (currentUser.role !== "admin") {
        router.push("/unauthorized");
      }
    }
  }, [currentUser, isLoading, router]);

  // Navigation tab state (defaults to Dashboard, or syncs with URL tab param)
  const tabParam = searchParams.get("tab")?.toLowerCase();
  const resolvedInitialTab = tabParam && SLUG_TO_LABEL[tabParam] ? SLUG_TO_LABEL[tabParam] : "Dashboard";
  const [activeNav, setActiveNav] = useState(resolvedInitialTab);
  const [selectedSemester, setSelectedSemester] = useState("Fall 2025");
  const [toastMessage, setToastMessage] = useState("");
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleNavClick = (label) => {
    setActiveNav(label);
    const slug = LABEL_TO_SLUG[label] || "overview";
    router.replace(`/dashboard/admin?tab=${slug}`, { scroll: false });
  };

  useEffect(() => {
    const currentTab = searchParams.get("tab")?.toLowerCase();
    if (currentTab && SLUG_TO_LABEL[currentTab]) {
      setActiveNav(SLUG_TO_LABEL[currentTab]);
    }
  }, [searchParams]);

  const showToast = (msg) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 4000);
  };

  const handleSwitchToStudent = async () => {
    try {
      await switchPersona("student");
      router.push("/dashboard/student");
    } catch (e) {
      console.error(e);
    }
  };

  // --- STATE FOR ALL CLUBS ---
  const [allClubsList, setAllClubsList] = useState([
    {
      id: "club-1",
      name: "Technical Club (ACM)",
      category: "Technical",
      lead: "Sarah Chen",
      coordinator: "Dr. S. Verma",
      totalMembers: 450,
      activeMembers: 320,
      trustScore: 92,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-2",
      name: "Robotics & Autonomous Lab",
      category: "Technical",
      lead: "Liam O'Connor",
      coordinator: "Prof. H. Tanaka",
      totalMembers: 210,
      activeMembers: 165,
      trustScore: 90,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-3",
      name: "Symphony & Music Society",
      category: "Cultural",
      lead: "Elena Rostova",
      coordinator: "Dr. M. Campbell",
      totalMembers: 185,
      activeMembers: 150,
      trustScore: 94,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-4",
      name: "Nritya Pan-Campus Dance Troupe",
      category: "Cultural",
      lead: "Ananya Deshmukh",
      coordinator: "Prof. V. Sharma",
      totalMembers: 210,
      activeMembers: 175,
      trustScore: 91,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-6",
      name: "University Football & Athletics",
      category: "Sports",
      lead: "Marcus Sterling",
      coordinator: "Coach J. Miller",
      totalMembers: 320,
      activeMembers: 260,
      trustScore: 95,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-7",
      name: "Hoops & Courts Basketball League",
      category: "Sports",
      lead: "Derrick Vance",
      coordinator: "Coach S. Riley",
      totalMembers: 195,
      activeMembers: 155,
      trustScore: 89,
      tier: "Tier 2 Silver",
      health: "Healthy",
    },
    {
      id: "club-10",
      name: "ShutterSpeed Photography Collective",
      category: "Photography",
      lead: "Dev Patel",
      coordinator: "Dr. A. Ghosh",
      totalMembers: 165,
      activeMembers: 135,
      trustScore: 93,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-12",
      name: "GreenCampus Eco & Sustainability",
      category: "Social Service",
      lead: "Aarav Mehta",
      coordinator: "Prof. L. Green",
      totalMembers: 275,
      activeMembers: 220,
      trustScore: 96,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
    {
      id: "club-14",
      name: "Growth Pulse & Brand Strategy",
      category: "Marketing",
      lead: "Vikram Malhotra",
      coordinator: "Prof. R. Khanna",
      totalMembers: 190,
      activeMembers: 150,
      trustScore: 91,
      tier: "Tier 1 Gold",
      health: "Healthy",
    },
  ]);

  // --- STATE FOR CONTRIBUTION ANALYTICS & MEMBERS ---
  const [selectedClubId, setSelectedClubId] = useState("club-1");
  const [memberSearch, setMemberSearch] = useState("");
  const [memberRoleFilter, setMemberRoleFilter] = useState("all");
  const [membersTable, setMembersTable] = useState([
    { id: 1, name: "Rahul Sharma", role: "Lead", tasks: 25, events: 8, score: 95, status: "Highly Active" },
    { id: 2, name: "Priya Singh", role: "Core Team", tasks: 18, events: 6, score: 85, status: "Active" },
    { id: 3, name: "Arjun Mehta", role: "Core Team", tasks: 15, events: 5, score: 80, status: "Active" },
    { id: 4, name: "Neha Gupta", role: "Member", tasks: 5, events: 2, score: 40, status: "Low" },
    { id: 5, name: "Karan Verma", role: "Member", tasks: 1, events: 0, score: 20, status: "Inactive" },
    { id: 6, name: "Riya Patel", role: "Member", tasks: 0, events: 1, score: 10, status: "Inactive" },
    { id: 7, name: "Aditya Kumar", role: "Member", tasks: 3, events: 0, score: 35, status: "Low" },
    { id: 8, name: "Sneha Jain", role: "Member", tasks: 1, events: 0, score: 10, status: "Inactive" },
  ]);

  // --- STATE FOR EVENTS & IMPACT AUDIT ---
  const [eventsList, setEventsList] = useState([
    {
      id: "ev-1",
      club: "Technical Club",
      title: "Fall AI Agent Workshop & LLM Hack",
      chair: "Rahul Sharma",
      venue: "Engineering Hall 302",
      date: "Oct 24, 2026",
      attendance: 48,
      status: "pending",
      fundAmount: "$1,200",
      attachments: "4 room captures, verified GitHub repo, signed attendee ledger",
    },
    {
      id: "ev-2",
      club: "Design Guild",
      title: "Quarterly UI/UX Critique & Portfolio Review",
      chair: "Maya Lin",
      venue: "Art Studio 4",
      date: "Oct 20, 2026",
      attendance: 34,
      status: "pending",
      fundAmount: "$650",
      attachments: "Figma project URL, catering receipt, attendee sign-in",
    },
    {
      id: "ev-3",
      club: "Robotics Club",
      title: "SumoBot Arena & Micro-Controller Workshop",
      chair: "Liam O'Connor",
      venue: "MakerLab 101",
      date: "Oct 18, 2026",
      attendance: 52,
      status: "pending",
      fundAmount: "$1,800",
      attachments: "Hardware invoices, lab safety sign-off, photo manifest",
    },
    {
      id: "ev-4",
      club: "Cultural Club",
      title: "Inter-College Music & Theater Showcase",
      chair: "Elena Rostova",
      venue: "Main Auditorium",
      date: "Oct 12, 2026",
      attendance: 140,
      status: "verified",
      fundAmount: "$2,400",
      attachments: "Auditorium booking contract, ticket check-in logs",
    },
  ]);

  const handleVerifyEvent = (id, clubName, fundAmount) => {
    setEventsList((prev) =>
      prev.map((e) => (e.id === id ? { ...e, status: "verified" } : e))
    );
    showToast(`Dean sign-off complete: ${clubName} verified and ${fundAmount} grant released!`);
  };

  // --- STATE FOR RECRUITMENT REVIEWS ---
  const [applicationsQueue, setApplicationsQueue] = useState([
    {
      id: "app-101",
      applicant: "Ayush",
      email: "ayush@campus.edu",
      department: "Computer Science",
      year: "2nd Year",
      clubName: "Technical Club",
      role: "Core Team — Web Developer",
      hours: 4,
      status: "pending",
      reason: "Excited to contribute to hackathons and build campus student tooling with React & Next.js.",
    },
    {
      id: "app-102",
      applicant: "Tanya Sharma",
      email: "tanya.s@campus.edu",
      department: "Information Systems",
      year: "3rd Year",
      clubName: "Marketing Club",
      role: "General Member & PR Associate",
      hours: 3,
      status: "pending",
      reason: "Experienced in Canva design, managing college fest Instagram pages, and sponsor outreach.",
    },
    {
      id: "app-103",
      applicant: "Rohan Varma",
      email: "rohan.v@campus.edu",
      department: "Mechanical Engineering",
      year: "1st Year",
      clubName: "Robotics Lab",
      role: "Hardware & Sensor Lab Associate",
      hours: 5,
      status: "pending",
      reason: "Passionate about Arduino, soldering, and building battle bots for inter-college leagues.",
    },
    {
      id: "app-104",
      applicant: "Sanya Kapoor",
      email: "sanya.k@campus.edu",
      department: "Media Studies",
      year: "2nd Year",
      clubName: "Design Guild",
      role: "UI/UX Apprentice",
      hours: 4,
      status: "pending",
      reason: "Proficient in Figma and graphic typography; eager to revamp student club brand identities.",
    },
  ]);

  const handleApproveApp = (id, name, club) => {
    setApplicationsQueue((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: "accepted" } : a))
    );
    showToast(`Approved: ${name}'s membership in ${club} is confirmed!`);
  };

  const handleRejectApp = (id, name) => {
    setApplicationsQueue((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: "rejected" } : a))
    );
    showToast(`Application for ${name} marked as rejected.`);
  };

  // --- STATE FOR USER MANAGEMENT ---
  const [usersList, setUsersList] = useState([
    { id: "u-1", name: "Rahul Sharma", email: "rahul@campus.edu", role: "Club Lead", club: "Technical Club", dept: "Computer Science", status: "Active" },
    { id: "u-2", name: "Dr. S. Verma", email: "s.verma@campus.edu", role: "Faculty Coordinator", club: "Technical Club", dept: "Computer Engineering", status: "Active" },
    { id: "u-3", name: "Sarah Chen", email: "sarah.c@campus.edu", role: "Club Lead", club: "ACM Chapter", dept: "Information Systems", status: "Active" },
    { id: "u-4", name: "Ayush", email: "ayush@campus.edu", role: "Student Member", club: "Technical Club", dept: "Computer Science", status: "Active" },
    { id: "u-5", name: "Maya Lin", email: "maya.l@campus.edu", role: "Club Lead", club: "Design Guild", dept: "Media Studies", status: "Active" },
    { id: "u-6", name: "Liam O'Connor", email: "liam.o@campus.edu", role: "Club Lead", club: "Robotics Lab", dept: "Mechanical Eng", status: "On Leave" },
  ]);

  // --- STATE FOR SETTINGS ---
  const [auditThreshold, setAuditThreshold] = useState(75);
  const [burnoutThreshold, setBurnoutThreshold] = useState(30);
  const [emailAlerts, setEmailAlerts] = useState(true);

  const handleSaveSettings = (e) => {
    e.preventDefault();
    showToast("Governance & audit threshold configuration saved successfully!");
  };

  if (isLoading || !currentUser || currentUser.role !== "admin") {
    return (
      <div className="min-h-screen bg-[#0F172A] flex flex-col items-center justify-center text-white text-xs gap-3">
        <div className="w-8 h-8 rounded-full border-2 border-blue-500 border-t-transparent animate-spin" />
        <p className="font-semibold text-slate-400">Verifying administrator clearance...</p>
      </div>
    );
  }

  return (
    <div className={`min-h-screen md:h-screen md:max-h-screen md:overflow-hidden p-2 sm:p-3 lg:p-4 flex flex-col md:flex-row gap-3 lg:gap-4 font-sans transition-colors duration-300 ${
      isDark ? "bg-[#030108] text-slate-100" : "bg-[#F2F4F8] text-slate-900"
    }`}>
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-6 right-6 z-50 bg-[#F37021] text-white px-4 py-2.5 rounded-2xl text-xs font-black shadow-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top">
          <CheckCircle2 className="h-4 w-4 text-white" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 1. CLUBPULSE DEAN SIDEBAR */}
      <aside className={`w-60 lg:w-64 flex flex-col justify-between shrink-0 hidden md:flex py-1.5 pl-2 pr-1 md:h-full md:overflow-y-auto transition-colors duration-300 ${
        isDark ? "bg-[#0A0514] text-slate-300 border-r border-white/10" : "bg-white text-slate-700 border-r border-slate-200 shadow-xs"
      }`}>
        <div>
          {/* Top Brand Logo */}
          <Link href="/" className="flex items-center gap-3 px-3 py-3 mb-6 group cursor-pointer">
            <div className="w-9 h-9 rounded-2xl bg-[#F37021] flex items-center justify-center text-white font-black shadow-md shadow-orange-500/20 group-hover:bg-[#EA580C] transition-colors">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <span className={`text-xl font-black tracking-tight leading-none block ${isDark ? "text-white" : "text-slate-900"}`}>
                Club<span className="text-[#F37021]">Pulse</span>
              </span>
              <span className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block mt-0.5">
                Dean Console
              </span>
            </div>
          </Link>

          {/* Nav Items */}
          <nav className="space-y-1 text-xs">
            {[
              { label: "Dashboard", icon: LayoutDashboard, badge: "3" },
              { label: "All Clubs", icon: Building2 },
              { label: "Contribution Analytics", icon: Activity },
              { label: "Events & Impact", icon: Calendar },
              { label: "Recruitment Reviews", icon: FileCheck },
              { label: "Reports", icon: FileText, badge: "1" },
              { label: "User Management", icon: UserCheck },
              { label: "Settings", icon: Settings },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.label;
              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => handleNavClick(item.label)}
                  className={`w-full flex items-center justify-between px-4 py-3 rounded-2xl transition-all cursor-pointer ${
                    isActive
                      ? "bg-white text-slate-900 font-extrabold shadow-md"
                      : isDark
                      ? "text-slate-400 hover:text-white hover:bg-white/5 font-semibold"
                      : "text-slate-600 hover:text-slate-900 hover:bg-white/60 font-semibold"
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <Icon className={`h-4 w-4 shrink-0 ${isActive ? "text-slate-900" : isDark ? "text-slate-400" : "text-slate-500"}`} />
                    <span className="text-xs">{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`px-2 py-0.5 rounded-full text-[11px] font-black ${
                        isActive
                          ? "bg-[#D2F863] text-slate-950"
                          : "bg-[#D2F863] text-slate-950"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Dean Governance Card & Switch View */}
        <div className="space-y-3 mt-6">
          <div className="bg-[#D2F863] text-slate-950 rounded-[28px] p-5 shadow-xl relative overflow-hidden">
            <div className="relative z-10">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                <h4 className="text-sm font-extrabold text-slate-950 tracking-tight leading-tight">
                  Dean Governance
                </h4>
              </div>
              <p className="text-[11px] font-semibold text-slate-800 mt-1 leading-snug">
                Academic Year 2025–2026 Audit Standing: Verified Compliant.
              </p>
              
              <div className="mt-3.5 pt-3 border-t border-slate-900/10 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => handleNavClick("Reports")}
                  className="px-3 py-1.5 rounded-xl bg-slate-950 text-white font-bold text-[11px] shadow-sm hover:scale-105 transition-transform cursor-pointer"
                >
                  View Dossier →
                </button>
                <span className="text-[10px] font-black uppercase tracking-wider text-slate-800">
                  24 Chapters
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={handleSwitchToStudent}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-2xl text-xs font-semibold transition-colors cursor-pointer ${
              isDark
                ? "bg-[#1C1D22] hover:bg-[#25272F] text-slate-300 hover:text-white"
                : "bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-2xs"
            }`}
          >
            <GraduationCap className="h-4 w-4 text-[#D2F863]" />
            <span>Switch to Student View</span>
          </button>
        </div>
      </aside>

      {/* 2. MAIN CONTENT INSET ISLAND */}
      <main className={`flex-1 rounded-[24px] sm:rounded-[32px] p-4 sm:p-6 lg:p-8 shadow-2xl md:h-full overflow-y-auto flex flex-col justify-between border transition-all duration-300 ${
        isDark ? "bg-[#14151B] border-white/10 text-white" : "bg-[#EBEEF2] border-slate-200/90 text-slate-900"
      }`}>
        <div>
          {/* Top Header Bar */}
          <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4">
            {/* User Profile with Switch Dropdown */}
            <div className="relative">
              <div
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-3 cursor-pointer group p-1.5 rounded-2xl hover:bg-white/5 transition-colors select-none"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-blue-500 to-purple-500 p-0.5 shadow-xs shrink-0">
                  <img
                    src={currentUser?.avatar || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"}
                    alt="Profile"
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className={`text-sm font-extrabold transition-colors ${isDark ? "text-white group-hover:text-[#D2F863]" : "text-slate-900 group-hover:text-blue-600"}`}>
                      {currentUser?.name || "Dean Administrator"}
                    </span>
                    <ChevronDown className="h-3.5 w-3.5 text-slate-500" />
                  </div>
                  <p className={`text-[11px] font-medium -mt-0.5 ${isDark ? "text-slate-400" : "text-slate-500"}`}>
                    {currentUser?.email || "marcus.vance@campus.edu"}
                  </p>
                </div>
              </div>

              {showProfileMenu && (
                <div className={`absolute left-0 mt-2 w-56 rounded-2xl p-2 shadow-2xl z-50 border ${
                  isDark ? "bg-[#181920] border-white/10 text-white" : "bg-white border-slate-200 text-slate-800"
                }`}>
                  <div className="px-3 py-2 border-b border-slate-100 dark:border-white/10 mb-1">
                    <p className="text-xs font-bold truncate">{currentUser?.name || "Administrator"}</p>
                    <p className="text-[10px] text-purple-400 font-semibold uppercase tracking-wider">Dean / Admin Role</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setShowProfileMenu(false);
                      handleSwitchToStudent();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-xl text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-950/40 transition-colors cursor-pointer text-left"
                  >
                    <GraduationCap className="h-4 w-4" />
                    <span>Switch to Student View</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowProfileMenu(false);
                      logout();
                      router.push("/login");
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer text-left"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Log Out</span>
                  </button>
                </div>
              )}
            </div>

            {/* Right Controls: Search + Theme Toggle + Notification Bell */}
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search..."
                  className={`w-56 sm:w-64 pl-10 pr-4 py-2.5 rounded-full text-xs transition-colors duration-300 focus:outline-none focus:ring-2 ${
                    isDark
                      ? "bg-[#1F2129] text-white placeholder-slate-400 border border-white/10 focus:ring-[#D2F863]/40"
                      : "bg-white text-slate-800 placeholder-slate-400 shadow-xs focus:ring-slate-300"
                  }`}
                />
              </div>

              {/* Theme Toggle Button */}
              <ThemeToggle />

              <div className="relative">
                <button
                  type="button"
                  onClick={() => showToast("2 unread Dean alerts in audit queue")}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                    isDark
                      ? "bg-[#1F2129] text-slate-200 border border-white/10 hover:text-white hover:border-[#D2F863]/50"
                      : "bg-white text-slate-700 shadow-xs hover:text-slate-900 hover:shadow-md"
                  }`}
                >
                  <Bell className="h-4 w-4" />
                </button>
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#D2F863] text-slate-950 font-black text-[10px] flex items-center justify-center shadow-xs">
                  2
                </span>
              </div>

              <button
                type="button"
                onClick={() => {
                  logout();
                  router.push("/login");
                }}
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  isDark
                    ? "bg-[#1F2129] text-slate-400 border border-white/10 hover:text-rose-400 hover:border-rose-400/40"
                    : "bg-white text-slate-500 shadow-xs hover:text-rose-600 hover:shadow-md"
                }`}
                title="Logout"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </header>

          {/* Page Heading Row */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mt-6 mb-7">
            <div>
              <h1 className={`text-3xl sm:text-4xl font-extrabold tracking-tight leading-tight transition-colors duration-300 ${
                isDark ? "text-white" : "text-slate-900"
              }`}>
                {activeNav === "Dashboard" && "Club Governance Overview"}
                {activeNav === "All Clubs" && "All Campus Clubs Management"}
                {activeNav === "Contribution Analytics" && "Member Contribution Analytics"}
                {activeNav === "Events & Impact" && "Events Verification & Impact Audit"}
                {activeNav === "Recruitment Reviews" && "Recruitment Reviews"}
                {activeNav === "Reports" && "Compliance Reports & Audit Dossiers"}
                {activeNav === "User Management" && "Campus User Accounts"}
                {activeNav === "Settings" && "Governance & Audit Parameters"}
              </h1>
              <p className={`text-xs sm:text-sm font-medium mt-1 transition-colors duration-300 ${
                isDark ? "text-slate-400" : "text-slate-500"
              }`}>
                {activeNav === "Dashboard" && "Real-time chapter health, member verified contributions, and audit compliance."}
                {activeNav !== "Dashboard" && "Inspect rosters, track activity proofs, and manage chapter health."}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <span className={`text-xs font-semibold ${isDark ? "text-slate-400" : "text-slate-500"}`}>
                Fall 2025 · Active Term
              </span>
              <button
                type="button"
                className={`rounded-full px-4 py-2 text-xs font-extrabold shadow-xs flex items-center gap-1.5 transition-all cursor-pointer ${
                  isDark
                    ? "bg-[#1F2129] text-white border border-white/10 hover:border-white/20"
                    : "bg-white text-slate-800 hover:shadow-md"
                }`}
              >
                <span>Today</span>
                <ChevronDown className="h-3 w-3 text-slate-500" />
              </button>
            </div>
          </div>

          {/* Mobile Navigation Tabs for small screens */}
          <div className="md:hidden flex items-center gap-2 overflow-x-auto pb-3 mb-5 border-b border-slate-200">
            {[
              { label: "Dashboard", icon: LayoutDashboard },
              { label: "All Clubs", icon: Building2 },
              { label: "Contribution Analytics", icon: Activity },
              { label: "Events & Impact", icon: Calendar },
              { label: "Recruitment Reviews", icon: FileCheck },
              { label: "Reports", icon: FileText },
              { label: "User Management", icon: UserCheck },
              { label: "Settings", icon: Settings },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeNav === item.label;
              return (
                <button
                  key={item.label}
                  type="button"
                  onClick={() => handleNavClick(item.label)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap shrink-0 transition-colors ${
                    isActive
                      ? "bg-white text-slate-900 shadow-xs"
                      : "bg-slate-200/70 text-slate-600 hover:bg-white"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* ============================================================== */}
          {/* VIEW 1: DASHBOARD (OVERVIEW) — CLUBPULSE GOVERNANCE TELEMETRY */}
          {/* ============================================================== */}
          {activeNav === "Dashboard" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch animate-in fade-in duration-200">
              {/* CARD 1 (LEFT COLUMN, 5 COLS): Verified Member Contributions */}
              <div className={`lg:col-span-5 rounded-[28px] p-6 sm:p-7 shadow-xs border flex flex-col justify-between transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white shadow-xl" : "bg-white border-slate-200/40 text-slate-900"
              }`}>
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isDark ? "bg-white/10 text-[#B4ACFF]" : "bg-purple-50 text-purple-600"}`}>
                        <Activity className="h-4 w-4" />
                      </div>
                      <span className={`text-sm font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>Verified Contributions</span>
                    </div>
                    <button className="text-slate-400 hover:text-slate-700 p-1" title="More options">
                      <span className="text-lg leading-none font-bold">⋮</span>
                    </button>
                  </div>

                  {/* Big Metric Display */}
                  <div className="mt-5 flex items-baseline gap-2">
                    <span className={`text-4xl sm:text-5xl font-black tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>
                      4,380
                    </span>
                    <span className="px-2 py-0.5 rounded-full bg-[#D9F99D] text-slate-900 font-extrabold text-[11px]">
                      +14%
                    </span>
                    <span className="text-xs text-slate-400 font-medium ml-1">tasks logged this term</span>
                  </div>

                  {/* Signature Triple Overlapping Bubbles Graphic */}
                  <div className="relative my-7 h-44 flex items-center justify-center">
                    {/* Circle 1: Lavender / Periwinkle */}
                    <div className="w-36 h-36 rounded-full bg-[#B4ACFF] flex flex-col items-center justify-center z-10 text-slate-900 shadow-md">
                      <span className="text-3xl font-black tracking-tight leading-none">2.6k</span>
                      <span className="text-[11px] font-bold text-slate-800 mt-1">Tech Tasks</span>
                    </div>

                    {/* Circle 2: Charcoal Black */}
                    <div className="w-32 h-32 rounded-full bg-[#18191E] flex flex-col items-center justify-center -ml-8 z-20 text-white shadow-md">
                      <span className="text-2xl font-black tracking-tight leading-none">1.2k</span>
                      <span className="text-[11px] font-medium text-slate-400 mt-1">Workshops</span>
                    </div>

                    {/* Circle 3: Neon Lime */}
                    <div className="w-24 h-24 rounded-full bg-[#D2F863] flex flex-col items-center justify-center -mt-16 ml-16 z-30 text-slate-950 shadow-lg">
                      <span className="text-xl font-black tracking-tight leading-none">540</span>
                      <span className="text-[10px] font-black text-slate-900 mt-0.5">Proofs</span>
                    </div>
                  </div>
                </div>

                {/* Horizontal Progress Bars */}
                <div className={`space-y-4 pt-4 border-t ${isDark ? "border-white/10" : "border-slate-100"}`}>
                  {/* Progress 1: 65% Active Member Verification (Lavender) */}
                  <div className="space-y-1.5">
                    <div className={`flex items-center justify-between text-xs font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>
                      <span className="text-lg">65 <span className="text-xs font-semibold text-slate-500">%</span></span>
                      <span className={`text-xs font-semibold flex items-center gap-1.5 ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                        Active Student Participation <span className="w-2 h-2 rounded-full bg-[#B4ACFF]" />
                      </span>
                    </div>
                    <div className={`w-full h-2.5 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-slate-100"}`}>
                      <div className="bg-[#B4ACFF] h-full rounded-full" style={{ width: "65%" }} />
                    </div>
                  </div>

                  {/* Progress 2: 25% Leadership Milestones (Charcoal) */}
                  <div className="space-y-1.5">
                    <div className={`flex items-center justify-between text-xs font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>
                      <span className="text-lg">25 <span className="text-xs font-semibold text-slate-500">%</span></span>
                      <span className={`text-xs font-semibold flex items-center gap-1.5 ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                        Officer Leadership Milestones <span className={`w-2 h-2 rounded-full ${isDark ? "bg-white" : "bg-[#18191E]"}`} />
                      </span>
                    </div>
                    <div className={`w-full h-2.5 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-slate-100"}`}>
                      <div className={`${isDark ? "bg-white" : "bg-[#18191E]"} h-full rounded-full`} style={{ width: "25%" }} />
                    </div>
                  </div>

                  {/* Progress 3: 10% Pending Audit Review (Neon Lime) */}
                  <div className="space-y-1.5">
                    <div className={`flex items-center justify-between text-xs font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>
                      <span className="text-lg">10 <span className="text-xs font-semibold text-slate-500">%</span></span>
                      <span className={`text-xs font-semibold flex items-center gap-1.5 ${isDark ? "text-slate-300" : "text-slate-600"}`}>
                        Pending Dean Audit Queue <span className="w-2 h-2 rounded-full bg-[#D2F863]" />
                      </span>
                    </div>
                    <div className={`w-full h-2.5 rounded-full overflow-hidden ${isDark ? "bg-white/10" : "bg-slate-100"}`}>
                      <div className="bg-[#D2F863] h-full rounded-full" style={{ width: "10%" }} />
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT AREA (7 COLS): Top 3 Sub-Cards + Wide Dark Card */}
              <div className="lg:col-span-7 flex flex-col justify-between gap-5">
                {/* TOP SUB-CARDS GRID */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-5">
                  {/* Card 2A: Chapter Health Score */}
                  <div className={`lg:col-span-6 rounded-[28px] p-5 sm:p-6 shadow-xs border flex flex-col justify-between transition-all duration-300 ${
                    isDark ? "bg-[#1C1E26] border-white/10 text-white shadow-xl" : "bg-white border-slate-200/40 text-slate-900"
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                          <Shield className="h-4 w-4" />
                        </div>
                        <span className={`text-sm font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>Chapter Health Score</span>
                      </div>
                      <button className="text-slate-400 hover:text-slate-700 p-1">
                        <span className="text-lg leading-none font-bold">⋮</span>
                      </button>
                    </div>

                    <div className="mt-4 flex items-baseline justify-between">
                      <div className="flex items-baseline gap-1.5">
                        <span className={`text-3xl sm:text-4xl font-black tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>94</span>
                        <span className="text-xs font-semibold text-slate-400">%</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Standing</span>
                        <span className={`text-xs font-extrabold ${isDark ? "text-[#D2F863]" : "text-emerald-600"}`}>Tier 1 Gold</span>
                      </div>
                    </div>
                  </div>

                  {/* Card 2B: Active Student Leaders */}
                  <div className={`lg:col-span-6 rounded-[28px] p-5 sm:p-6 shadow-xs border flex flex-col justify-between transition-all duration-300 ${
                    isDark ? "bg-[#1C1E26] border-white/10 text-white shadow-xl" : "bg-white border-slate-200/40 text-slate-900"
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                          <Users className="h-4 w-4" />
                        </div>
                        <span className={`text-sm font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>Active Student Leaders</span>
                      </div>
                      <button className="text-slate-400 hover:text-slate-700 p-1">
                        <span className="text-lg leading-none font-bold">⋮</span>
                      </button>
                    </div>

                    <div className="mt-4 flex items-baseline justify-between">
                      <div className="flex items-baseline gap-1.5">
                        <span className={`text-3xl sm:text-4xl font-black tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>148</span>
                        <span className="text-xs font-semibold text-slate-400">officers</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 uppercase font-bold block">Coverage</span>
                        <span className={`text-xs font-extrabold ${isDark ? "text-slate-200" : "text-slate-800"}`}>24 Chapters</span>
                      </div>
                    </div>
                  </div>

                  {/* Card 3: Ghost Member Prevention Index */}
                  <div className={`sm:col-span-2 lg:col-span-12 rounded-[28px] p-5 sm:p-6 shadow-xs border flex flex-col justify-between transition-all duration-300 ${
                    isDark ? "bg-[#1C1E26] border-white/10 text-white shadow-xl" : "bg-white border-slate-200/40 text-slate-900"
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-purple-50 flex items-center justify-center text-purple-600 font-extrabold text-xs">
                          <CheckCircle2 className="h-4 w-4" />
                        </div>
                        <span className={`text-sm font-extrabold ${isDark ? "text-white" : "text-slate-900"}`}>Ghost Member Prevention Index</span>
                      </div>
                      <button className="text-slate-400 hover:text-slate-700 p-1">
                        <span className="text-lg leading-none font-bold">⋮</span>
                      </button>
                    </div>

                    <div className="mt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-baseline gap-2">
                        <span className={`text-3xl sm:text-4xl font-black tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>98.4</span>
                        <span className="text-xs font-semibold text-slate-400">%</span>
                        <span className="px-2 py-0.5 rounded-full bg-[#D9F99D] text-slate-900 font-extrabold text-[11px] ml-1">
                          +5.2% verified participation
                        </span>
                      </div>

                      {/* 5-row dot matrix grid in lavender colors representing student participation clusters */}
                      <div className="flex items-center gap-2" title="Department verification clusters">
                        {[
                          [0, 0, 1, 1, 1],
                          [0, 1, 1, 1, 1],
                          [1, 1, 0, 1, 1],
                          [0, 1, 1, 0, 1],
                          [0, 0, 1, 1, 1],
                          [1, 1, 1, 1, 1],
                          [0, 1, 1, 1, 1],
                          [0, 0, 1, 1, 1],
                          [1, 1, 1, 1, 1],
                          [1, 1, 1, 1, 1],
                        ].map((col, cIdx) => (
                          <div key={cIdx} className="flex flex-col gap-1.5">
                            {col.map((dot, rIdx) => (
                              <div
                                key={rIdx}
                                className={`w-2.5 h-2.5 rounded-full transition-all ${
                                  dot === 1
                                    ? "bg-[#B4ACFF]"
                                    : isDark
                                    ? "bg-white/10"
                                    : "bg-slate-200/80"
                                }`}
                              />
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* SIGNATURE HIGH-CONTRAST DARK CARD: Semester Contribution & Audit Velocity */}
                <div className={`rounded-[28px] p-6 sm:p-7 shadow-xl border transition-all duration-300 ${
                  isDark ? "bg-[#101115] border-white/10 text-white" : "bg-[#18191E] border-slate-800 text-white"
                }`}>
                  {/* Header */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-[#24252D] flex items-center justify-center text-[#D2F863]">
                        <TrendingUp className="h-4 w-4" />
                      </div>
                      <span className="text-base font-extrabold text-white tracking-tight">Semester Contribution &amp; Audit Telemetry</span>
                    </div>

                    <button
                      type="button"
                      className="bg-[#2B2C33] text-slate-300 hover:text-white px-3.5 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>Fall 2025</span>
                      <ChevronDown className="h-3 w-3 text-slate-400" />
                    </button>
                  </div>

                  {/* Two KPI Indicators */}
                  <div className="flex items-center gap-8 mb-6">
                    <div className="flex items-start gap-2.5">
                      <div className="w-1.5 h-7 rounded-full bg-[#D2F863]" />
                      <div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-black text-white">96.8</span>
                          <span className="text-xs text-slate-400">%</span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-medium">Audit Compliance Rate</span>
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <div className="w-1.5 h-7 rounded-full bg-[#B4ACFF]" />
                      <div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-black text-white">$48,500</span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-medium">Verified Club Funding</span>
                      </div>
                    </div>
                  </div>

                  {/* Custom Rounded Bar Chart */}
                  <div className="flex items-end justify-between gap-2 sm:gap-4 pt-4 border-t border-[#262831] h-36">
                    {[
                      { month: "Jun", height: "45%" },
                      { month: "Jul", height: "60%" },
                      { month: "Aug", height: "50%" },
                      {
                        month: "Sept ↗",
                        isHighlight: true,
                        limeHeight: "85%",
                        lilacHeight: "65%",
                      },
                      { month: "Oct", height: "40%" },
                      { month: "Nov", height: "55%" },
                      { month: "Dec", height: "35%" },
                    ].map((col) => {
                      if (col.isHighlight) {
                        return (
                          <div key={col.month} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                            <div className="flex items-end gap-1.5 h-full w-full justify-center">
                              <div
                                className="w-3.5 sm:w-4.5 rounded-full bg-[#D2F863] shadow-md shadow-[#D2F863]/30 transition-all"
                                style={{ height: col.limeHeight }}
                              />
                              <div
                                className="w-3.5 sm:w-4.5 rounded-full bg-[#B4ACFF] shadow-md shadow-[#B4ACFF]/30 transition-all"
                                style={{ height: col.lilacHeight }}
                              />
                            </div>
                            <span className="text-[11px] font-extrabold text-[#D2F863] tracking-wider whitespace-nowrap">
                              {col.month}
                            </span>
                          </div>
                        );
                      }

                      return (
                        <div key={col.month} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                          <div className="w-7 sm:w-8 h-full flex items-end justify-center">
                            <div
                              className="w-full rounded-2xl bar-striped-dark border border-white/5 opacity-80 hover:opacity-100 transition-opacity"
                              style={{ height: col.height }}
                            />
                          </div>
                          <span className="text-[11px] font-medium text-slate-500">
                            {col.month}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

        {/* ============================================================== */}
        {/* VIEW 2: ALL CLUBS */}
        {/* ============================================================== */}
        {activeNav === "All Clubs" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className={`rounded-3xl border shadow-xs overflow-hidden transition-all duration-300 ${
              isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
            }`}>
              <div className={`p-6 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                isDark ? "border-white/10" : "border-slate-100"
              }`}>
                <div>
                  <h2 className={`text-base font-bold tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>Campus Organization Directory</h2>
                  <p className={`text-xs mt-0.5 ${isDark ? "text-slate-400" : "text-slate-500"}`}>Showing all registered chapters, designated leads, and audit standing</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-3 py-1.5 rounded-xl border ${
                    isDark ? "bg-white/10 text-[#D2F863] border-white/15" : "bg-blue-50 text-blue-700 border-blue-200"
                  }`}>
                    24 Total Chapters
                  </span>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className={`border-b text-[11px] font-bold uppercase tracking-wider ${
                      isDark ? "border-white/10 bg-white/5 text-slate-400" : "border-slate-100 bg-slate-50/70 text-slate-500"
                    }`}>
                      <th className="py-3 px-5">Club Name</th>
                      <th className="py-3 px-5">Category</th>
                      <th className="py-3 px-5">Club Lead</th>
                      <th className="py-3 px-5">Faculty Coordinator</th>
                      <th className="py-3 px-5 text-center">Members (Active / Total)</th>
                      <th className="py-3 px-5 text-center">Trust Score</th>
                      <th className="py-3 px-5 text-center">Health Status</th>
                      <th className="py-3 px-5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className={`divide-y ${isDark ? "divide-white/10 text-slate-200" : "divide-slate-100 text-slate-700"}`}>
                    {allClubsList.map((c) => (
                      <tr key={c.id} className={`${isDark ? "hover:bg-white/5" : "hover:bg-slate-50/80"} transition-colors`}>
                        <td className={`py-4 px-5 font-bold ${isDark ? "text-white" : "text-slate-900"}`}>
                          {c.name}
                        </td>
                        <td className="py-4 px-5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isDark ? "bg-white/10 text-slate-300" : "bg-slate-100 text-slate-700"
                          }`}>
                            {c.category}
                          </span>
                        </td>
                        <td className="py-4 px-5 font-medium">{c.lead}</td>
                        <td className={`py-4 px-5 ${isDark ? "text-slate-400" : "text-slate-500"}`}>{c.coordinator}</td>
                        <td className="py-4 px-5 text-center font-mono">
                          <span className="font-bold text-emerald-500">{c.activeMembers}</span> / {c.totalMembers}
                        </td>
                        <td className={`py-4 px-5 text-center font-mono font-bold ${isDark ? "text-white" : "text-slate-900"}`}>
                          {c.trustScore}/100
                        </td>
                        <td className="py-4 px-5 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                              c.health === "Healthy"
                                ? isDark ? "bg-emerald-950/40 text-emerald-400 border-emerald-800/40" : "bg-emerald-50 text-emerald-700 border-emerald-200"
                                : c.health === "Needs Attention"
                                ? isDark ? "bg-amber-950/40 text-amber-400 border-amber-800/40" : "bg-amber-50 text-amber-700 border-amber-200"
                                : isDark ? "bg-rose-950/40 text-rose-400 border-rose-800/40" : "bg-rose-50 text-rose-700 border-rose-200"
                            }`}
                          >
                            {c.health}
                          </span>
                        </td>
                        <td className="py-4 px-5 text-right">
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedClubId(c.id);
                              setActiveNav("Contribution Analytics");
                            }}
                            className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-colors cursor-pointer ${
                              isDark ? "bg-white/10 hover:bg-[#D2F863] text-white hover:text-slate-950" : "bg-blue-50 hover:bg-blue-100 text-blue-700"
                            }`}
                          >
                            Inspect Roster →
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 3: CONTRIBUTION ANALYTICS & OVERLOAD (SCREEN 5) */}
        {/* ============================================================== */}
        {activeNav === "Contribution Analytics" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Club Header & Metrics */}
            <div className={`rounded-3xl border p-6 sm:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6 transition-all duration-300 ${
              isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
            }`}>
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 rounded-2xl bg-[#F37021] flex items-center justify-center text-white shrink-0 shadow-md shadow-orange-500/20">
                  <GraduationCap className="h-8 w-8" />
                </div>
                <div className="space-y-1">
                  <h2 className={`text-2xl font-extrabold tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>
                    Technical Club
                  </h2>
                  <p className={`text-xs font-medium ${isDark ? "text-slate-400" : "text-slate-500"}`}>Build. Learn. Innovate.</p>
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {["Technology", "Workshops", "Hackathons"].map((t) => (
                      <span key={t} className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                        isDark ? "bg-white/10 text-blue-300 border-white/10" : "bg-blue-50 text-blue-700 border-blue-200/60"
                      }`}>
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-6 text-xs">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Faculty Coordinator</span>
                  <span className={`font-extrabold text-sm mt-0.5 block ${isDark ? "text-white" : "text-slate-900"}`}>Dr. S. Verma</span>
                </div>
                <div className={`h-8 w-px hidden sm:block ${isDark ? "bg-white/10" : "bg-slate-200"}`} />
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Club Lead</span>
                  <span className={`font-extrabold text-sm mt-0.5 block ${isDark ? "text-white" : "text-slate-900"}`}>Rahul Sharma</span>
                </div>
              </div>
            </div>

            {/* 4 Stat Metric Cards */}
            <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
              }`}>
                <span className={`text-2xl font-extrabold font-mono block ${isDark ? "text-white" : "text-slate-900"}`}>450</span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Total Members</span>
              </div>
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
              }`}>
                <span className={`text-2xl font-extrabold font-mono block ${isDark ? "text-white" : "text-slate-900"}`}>120</span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Active Members (26%)</span>
              </div>
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
              }`}>
                <span className="text-2xl font-extrabold text-rose-500 font-mono block">320</span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Inactive Members</span>
              </div>
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
              }`}>
                <span className={`text-2xl font-extrabold font-mono block ${isDark ? "text-white" : "text-slate-900"}`}>8</span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Core Team Members</span>
              </div>
            </section>

            {/* Member Contributions Table */}
            <div className={`rounded-3xl border shadow-xs overflow-hidden transition-all duration-300 ${
              isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
            }`}>
              <div className={`p-5 sm:p-6 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                isDark ? "border-white/10" : "border-slate-100"
              }`}>
                <div>
                  <h3 className={`text-base font-bold tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>Member Contributions</h3>
                  <p className={`text-xs mt-0.5 ${isDark ? "text-slate-400" : "text-slate-500"}`}>Individual workload, event attendance, and activity rating</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
                    <input
                      type="text"
                      value={memberSearch}
                      onChange={(e) => setMemberSearch(e.target.value)}
                      placeholder="Search member name..."
                      className={`pl-8 pr-3 py-1.5 text-xs rounded-xl focus:outline-none transition-colors ${
                        isDark ? "bg-[#22242D] border border-white/10 text-white placeholder-slate-400" : "bg-slate-50 border border-slate-200 text-slate-800 placeholder-slate-400"
                      }`}
                    />
                  </div>
                  <select
                    value={memberRoleFilter}
                    onChange={(e) => setMemberRoleFilter(e.target.value)}
                    className={`rounded-xl px-3 py-1.5 text-xs font-semibold ${
                      isDark ? "bg-[#22242D] border border-white/10 text-slate-200" : "bg-slate-50 border border-slate-200 text-slate-700"
                    }`}
                  >
                    <option value="all">All Members</option>
                    <option value="lead">Leadership</option>
                    <option value="inactive">Inactive Only</option>
                  </select>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className={`border-b text-[11px] font-bold uppercase tracking-wider ${
                      isDark ? "border-white/10 bg-white/5 text-slate-400" : "border-slate-100 bg-slate-50/70 text-slate-500"
                    }`}>
                      <th className="py-3 px-5">#</th>
                      <th className="py-3 px-5">Name</th>
                      <th className="py-3 px-5">Role</th>
                      <th className="py-3 px-5 text-center">Tasks Completed</th>
                      <th className="py-3 px-5 text-center">Events Participated</th>
                      <th className="py-3 px-5 w-44">Contribution Score</th>
                      <th className="py-3 px-5 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className={`divide-y ${isDark ? "divide-white/10 text-slate-200" : "divide-slate-100 text-slate-700"}`}>
                    {membersTable
                      .filter((m) => m.name.toLowerCase().includes(memberSearch.toLowerCase()))
                      .map((m) => (
                        <tr key={m.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3.5 px-5 font-mono text-slate-400 font-semibold">{m.id}</td>
                          <td className="py-3.5 px-5 font-bold text-slate-900">{m.name}</td>
                          <td className="py-3.5 px-5 text-slate-600 font-medium">{m.role}</td>
                          <td className="py-3.5 px-5 text-center font-mono font-bold text-slate-800">{m.tasks}</td>
                          <td className="py-3.5 px-5 text-center font-mono font-bold text-slate-800">{m.events}</td>
                          <td className="py-3.5 px-5">
                            <div className="flex items-center gap-3">
                              <div className="w-24 bg-slate-100 h-2 rounded-full overflow-hidden">
                                <div
                                  className={`h-full rounded-full ${
                                    m.score >= 80 ? "bg-emerald-500" : m.score >= 35 ? "bg-amber-500" : "bg-rose-500"
                                  }`}
                                  style={{ width: `${m.score}%` }}
                                />
                              </div>
                              <span className="font-mono font-bold text-slate-800 text-[11px]">{m.score}</span>
                            </div>
                          </td>
                          <td className="py-3.5 px-5 text-center">
                            <span
                              className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                                m.status === "Highly Active" || m.status === "Active"
                                  ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                                  : m.status === "Low"
                                  ? "bg-amber-50 text-amber-700 border-amber-200"
                                  : "bg-rose-50 text-rose-700 border-rose-200"
                              }`}
                            >
                              {m.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* ============================================================== */}
        {/* VIEW 4: EVENTS & IMPACT VERIFICATION (USER'S CLICKED SECTION) */}
        {/* ============================================================== */}
        {activeNav === "Events & Impact" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            {/* Quick Summary Banner */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200 shadow-xs"
              }`}>
                <span className="text-2xl font-extrabold text-blue-500 font-mono block">138</span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Verified Campus Activities</span>
              </div>
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200 shadow-xs"
              }`}>
                <span className="text-2xl font-extrabold text-emerald-500 font-mono block">$24,500</span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Disbursed Co-Curricular Funding</span>
              </div>
              <div className={`p-5 rounded-2xl border shadow-xs transition-all duration-300 ${
                isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200 shadow-xs"
              }`}>
                <span className={`text-2xl font-extrabold font-mono block ${isDark ? "text-white" : "text-slate-900"}`}>
                  {eventsList.filter((e) => e.status === "pending").length} Pending
                </span>
                <span className={`text-xs font-medium mt-1 block ${isDark ? "text-slate-400" : "text-slate-500"}`}>Audit Queue Turnaround: 18.4 hrs</span>
              </div>
            </div>

            {/* Audit Queue List */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h2 className={`text-base font-bold tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>Priority Event Verification Queue</h2>
                <span className={`text-xs font-bold ${isDark ? "text-slate-400" : "text-slate-500"}`}>
                  {eventsList.filter((e) => e.status === "pending").length} requiring Dean authorization
                </span>
              </div>

              {eventsList.map((ev) => {
                const isVerified = ev.status === "verified";
                return (
                  <div
                    key={ev.id}
                    className={`p-6 rounded-3xl border shadow-xs flex flex-col gap-4 transition-all duration-300 ${
                      isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 text-xs">
                          <span className={`font-bold font-mono ${isDark ? "text-[#D2F863]" : "text-blue-600"}`}>{ev.club}</span>
                          <span className={isDark ? "text-white/20" : "text-slate-300"}>•</span>
                          <span className={isDark ? "text-slate-300" : "text-slate-500"}>{ev.chair}</span>
                          <span className={isDark ? "text-white/20" : "text-slate-300"}>•</span>
                          <span className={isDark ? "text-slate-300" : "text-slate-500"}>{ev.venue}</span>
                        </div>
                        <h3 className={`text-base font-bold mt-1 ${isDark ? "text-white" : "text-slate-900"}`}>{ev.title}</h3>
                      </div>

                      <span
                        className={`self-start px-2.5 py-1 rounded-full text-[11px] font-bold border flex items-center gap-1.5 ${
                          isVerified
                            ? isDark ? "bg-emerald-950/40 text-emerald-400 border-emerald-800/40" : "bg-emerald-50 text-emerald-700 border-emerald-200"
                            : isDark ? "bg-amber-950/40 text-amber-400 border-amber-800/40" : "bg-amber-50 text-amber-700 border-amber-200"
                        }`}
                      >
                        {isVerified ? (
                          <>
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            <span>Signatures Verified</span>
                          </>
                        ) : (
                          <>
                            <Clock className="h-3.5 w-3.5" />
                            <span>Audit Pending</span>
                          </>
                        )}
                      </span>
                    </div>

                    {/* Telemetry info */}
                    <div className={`grid grid-cols-1 sm:grid-cols-3 gap-3 p-3.5 rounded-2xl text-xs font-mono border ${
                      isDark ? "bg-[#22242D] border-white/10 text-white" : "bg-slate-50 border-slate-100 text-slate-900"
                    }`}>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Verified Attendance</span>
                        <span className={`font-bold text-xs mt-0.5 block ${isDark ? "text-white" : "text-slate-900"}`}>{ev.attendance} Attendees</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Grant Amount</span>
                        <span className={`font-bold text-xs mt-0.5 block ${isDark ? "text-[#D2F863]" : "text-blue-600"}`}>{ev.fundAmount}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px] uppercase font-bold">Event Date</span>
                        <span className={`font-bold text-xs mt-0.5 block ${isDark ? "text-slate-200" : "text-slate-700"}`}>{ev.date}</span>
                      </div>
                    </div>

                    <p className={`text-xs flex items-center gap-1.5 ${isDark ? "text-slate-300" : "text-slate-500"}`}>
                      <FileCheck className={`h-4 w-4 shrink-0 ${isDark ? "text-[#D2F863]" : "text-blue-600"}`} />
                      <span>{ev.attachments}</span>
                    </p>

                    <div className={`pt-3 border-t flex items-center justify-end gap-3 ${isDark ? "border-white/10" : "border-slate-100"}`}>
                      {!isVerified ? (
                        <button
                          type="button"
                          onClick={() => handleVerifyEvent(ev.id, ev.club, ev.fundAmount)}
                          className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 active:scale-95 cursor-pointer"
                        >
                          <CheckCircle2 className="h-4 w-4" />
                          <span>Authorize Sign-off & Disburse {ev.fundAmount}</span>
                        </button>
                      ) : (
                        <span className="text-xs font-bold text-emerald-500 flex items-center gap-1">
                          <Check className="h-4 w-4" /> Grant Released
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 5: RECRUITMENT REVIEWS */}
        {/* ============================================================== */}
        {activeNav === "Recruitment Reviews" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className={`rounded-3xl border shadow-xs overflow-hidden transition-all duration-300 ${
              isDark ? "bg-[#1C1E26] border-white/10 text-white" : "bg-white border-slate-200/90 text-slate-900"
            }`}>
              <div className={`p-6 border-b flex items-center justify-between ${isDark ? "border-white/10" : "border-slate-100"}`}>
                <div>
                  <h2 className={`text-base font-bold tracking-tight ${isDark ? "text-white" : "text-slate-900"}`}>Student Membership Applications</h2>
                  <p className={`text-xs mt-0.5 ${isDark ? "text-slate-400" : "text-slate-500"}`}>Approve, under-review, or reject student applicants across all campus organizations</p>
                </div>
                <span className={`text-xs font-bold px-3 py-1.5 rounded-xl border ${
                  isDark ? "bg-white/10 text-purple-300 border-white/15" : "bg-purple-50 text-purple-700 border-purple-200"
                }`}>
                  {applicationsQueue.length} Applications
                </span>
              </div>

              <div className={`divide-y ${isDark ? "divide-white/10" : "divide-slate-100"}`}>
                {applicationsQueue.map((app) => (
                  <div key={app.id} className={`p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors ${
                    isDark ? "hover:bg-white/5" : "hover:bg-slate-50/50"
                  }`}>
                    <div className="space-y-1.5 max-w-2xl">
                      <div className="flex items-center gap-2.5">
                        <h4 className={`text-sm font-bold ${isDark ? "text-white" : "text-slate-900"}`}>{app.applicant}</h4>
                        <span className={`text-xs font-mono ${isDark ? "text-slate-400" : "text-slate-400"}`}>({app.email})</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          isDark ? "bg-white/10 text-[#D2F863]" : "bg-blue-50 text-blue-700"
                        }`}>
                          {app.clubName}
                        </span>
                      </div>
                      <p className={`text-xs font-semibold ${isDark ? "text-slate-300" : "text-slate-700"}`}>
                        Applying for: <span className={isDark ? "text-blue-400 font-bold" : "text-blue-600 font-bold"}>{app.role}</span> · {app.hours} hrs/wk capacity
                      </p>
                      <p className={`text-xs italic p-3 rounded-xl border ${
                        isDark ? "bg-[#22242D] border-white/10 text-slate-300" : "bg-slate-50 border-slate-100 text-slate-600"
                      }`}>
                        "{app.reason}"
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-start md:self-center shrink-0">
                      {app.status === "pending" ? (
                        <>
                          <button
                            type="button"
                            onClick={() => handleRejectApp(app.id, app.applicant)}
                            className="px-3.5 py-2 rounded-xl border border-slate-200 hover:bg-rose-50 hover:text-rose-600 text-xs font-bold text-slate-600 transition-colors"
                          >
                            Reject
                          </button>
                          <button
                            type="button"
                            onClick={() => handleApproveApp(app.id, app.applicant, app.clubName)}
                            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                          >
                            <Check className="h-3.5 w-3.5" />
                            <span>Approve</span>
                          </button>
                        </>
                      ) : (
                        <span
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${
                            app.status === "accepted"
                              ? "bg-emerald-50 text-emerald-700 border-emerald-200"
                              : "bg-rose-50 text-rose-700 border-rose-200"
                          }`}
                        >
                          {app.status.toUpperCase()}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 6: REPORTS & AUDIT DOSSIERS */}
        {/* ============================================================== */}
        {activeNav === "Reports" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {[
                {
                  title: "Fall 2025 Comprehensive Club Audit Report",
                  desc: "Verified student outcomes, attendance quotas, and Dean sign-offs across all 24 chartered campus organizations.",
                  format: "PDF (3.4 MB)",
                  date: "Compiled Oct 28, 2026",
                },
                {
                  title: "Officer Workload & Burnout Telemetry Dossier",
                  desc: "Analysis of hours carried by club presidents, rebalanced task history, and volunteer fatigue indicators.",
                  format: "CSV / Sheet (1.2 MB)",
                  date: "Updated Weekly",
                },
                {
                  title: "Campus Budget Allocation & Receipt Reconciliation Ledger",
                  desc: "Itemized receipts, room reservation records, and university grant disbursements for co-curricular clubs.",
                  format: "PDF (4.8 MB)",
                  date: "Compiled Oct 25, 2026",
                },
                {
                  title: "Ghost Membership & Academic Exam Shield Summary",
                  desc: "Log of excused absence periods during midterms/finals to verify zero punitive club drops.",
                  format: "CSV (820 KB)",
                  date: "Active Semester",
                },
              ].map((rep, idx) => (
                <div key={idx} className="p-6 rounded-3xl bg-white border border-slate-200/90 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                      <FileDown className="h-5 w-5" />
                    </div>
                    <h3 className="text-base font-bold text-slate-900 leading-snug">{rep.title}</h3>
                    <p className="text-xs text-slate-600 mt-2 leading-relaxed">{rep.desc}</p>
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400 font-medium">
                      <span>{rep.format}</span>
                      <span>{rep.date}</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => showToast(`Downloaded: ${rep.title}`)}
                    className="mt-5 w-full py-2.5 rounded-xl bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-blue-600 border border-slate-200 text-xs font-bold transition-colors flex items-center justify-center gap-2"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download Report</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 7: USER MANAGEMENT */}
        {/* ============================================================== */}
        {activeNav === "User Management" && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xs overflow-hidden">
              <div className="p-6 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-slate-900 tracking-tight">Campus User Accounts</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Student leaders, faculty coordinators, and registered members</p>
                </div>
                <button
                  onClick={() => showToast("New user invite link generated!")}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Campus Lead</span>
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 bg-slate-50/70 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-5">Name & Email</th>
                      <th className="py-3 px-5">System Role</th>
                      <th className="py-3 px-5">Assigned Club</th>
                      <th className="py-3 px-5">Department</th>
                      <th className="py-3 px-5 text-center">Status</th>
                      <th className="py-3 px-5 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {usersList.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3.5 px-5">
                          <span className="font-bold text-slate-900 block">{u.name}</span>
                          <span className="text-[11px] text-slate-400 font-mono block">{u.email}</span>
                        </td>
                        <td className="py-3.5 px-5 font-semibold text-slate-800">{u.role}</td>
                        <td className="py-3.5 px-5 text-blue-600 font-medium">{u.club}</td>
                        <td className="py-3.5 px-5 text-slate-500">{u.dept}</td>
                        <td className="py-3.5 px-5 text-center">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            {u.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-5 text-right">
                          <button
                            type="button"
                            onClick={() => showToast(`User permissions updated for ${u.name}`)}
                            className="px-3 py-1 rounded-lg border border-slate-200 text-slate-600 hover:text-blue-600 text-xs font-semibold"
                          >
                            Edit
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* VIEW 8: SETTINGS */}
        {/* ============================================================== */}
        {activeNav === "Settings" && (
          <div className="max-w-2xl bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6 animate-in fade-in duration-200">
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">Audit & Governance Parameters</h2>
              <p className="text-xs text-slate-500 mt-1">Configure automated threshold rules for university club funding and burnout alerts</p>
            </div>

            {/* Appearance & Interface Theme Selector */}
            <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Appearance &amp; Theme</h3>
                  <p className="text-[11px] text-slate-500 mt-0.5">Toggle interface contrast and color modes across all views</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase px-2.5 py-1 rounded-full bg-slate-200 text-slate-800">
                    {theme} Mode
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Dark Mode Card */}
                <button
                  type="button"
                  onClick={() => {
                    setTheme("dark");
                    showToast("ClubPulse Dark Mode activated");
                  }}
                  className={`p-3.5 rounded-2xl border flex items-center gap-3.5 transition-all cursor-pointer text-left ${
                    isDark
                      ? "border-slate-900 bg-[#121316] text-white shadow-md ring-2 ring-[#D2F863]"
                      : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                  }`}
                >
                  <div className="w-9 h-9 rounded-xl bg-[#18191E] flex items-center justify-center text-[#D2F863] shrink-0 shadow-xs">
                    <Moon className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold block text-white">ClubPulse Dark</span>
                    <span className="text-[11px] text-slate-400">Deep obsidian &amp; neon accents</span>
                  </div>
                  {isDark && (
                    <span className="ml-auto w-2 h-2 rounded-full bg-[#D2F863]" />
                  )}
                </button>

                {/* Light Mode Card */}
                <button
                  type="button"
                  onClick={() => {
                    setTheme("light");
                    showToast("ClubPulse Light Mode activated");
                  }}
                  className={`p-3.5 rounded-2xl border flex items-center gap-3.5 transition-all cursor-pointer text-left ${
                    !isDark
                      ? "border-blue-600 bg-white text-slate-900 shadow-md ring-2 ring-blue-500"
                      : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                  }`}
                >
                  <div className="w-9 h-9 rounded-xl bg-amber-50 flex items-center justify-center text-amber-500 shrink-0 shadow-xs">
                    <Sun className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold block text-slate-900">ClubPulse Light</span>
                    <span className="text-[11px] text-slate-500">Clean platinum &amp; crisp whites</span>
                  </div>
                  {!isDark && (
                    <span className="ml-auto w-2 h-2 rounded-full bg-blue-600" />
                  )}
                </button>
              </div>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Active Term / Semester
                </label>
                <input
                  type="text"
                  value={selectedSemester}
                  onChange={(e) => setSelectedSemester(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2 text-xs font-bold text-slate-800"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Minimum Trust Score for Dean Grant Disbursement</span>
                  <span className="font-mono text-blue-600 font-bold">{auditThreshold} / 100</span>
                </div>
                <input
                  type="range"
                  min={50}
                  max={95}
                  value={auditThreshold}
                  onChange={(e) => setAuditThreshold(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                  <span>Officer Workload Overload Alert Threshold</span>
                  <span className="font-mono text-amber-600 font-bold">&gt; {burnoutThreshold}% load</span>
                </div>
                <input
                  type="range"
                  min={20}
                  max={50}
                  value={burnoutThreshold}
                  onChange={(e) => setBurnoutThreshold(Number(e.target.value))}
                  className="w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={emailAlerts}
                    onChange={(e) => setEmailAlerts(e.target.checked)}
                    className="rounded text-blue-600 focus:ring-blue-500 h-4 w-4"
                  />
                  <span>Send instant Dean alerts when club active quota drops below quorum</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs"
                >
                  Save Configuration
                </button>
              </div>
            </form>
          </div>
        )}
        </div>
      </main>
    </div>
  );
}

export default function AdminDashboardPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-[#121316] flex items-center justify-center text-slate-300 text-xs">
          Loading Dean & Admin Console...
        </div>
      }
    >
      <AdminDashboardContent />
    </Suspense>
  );
}
