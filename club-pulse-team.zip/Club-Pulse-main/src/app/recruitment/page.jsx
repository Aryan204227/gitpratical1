"use client";
import React, { useState } from "react";
import Link from "next/link";
import ApplyClubModal from "@/components/ApplyClubModal";
import {
  Briefcase,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ArrowRight,
  Zap,
  Megaphone,
  Palette,
  Bot,
  Music,
  Users,
  Calendar,
  Building2,
  ChevronRight,
  Trophy,
  Camera,
  Compass,
} from "lucide-react";

export default function RecruitmentHubPage() {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedClub, setSelectedClub] = useState(null);
  const [selectedRole, setSelectedRole] = useState(null);
  const [toastMessage, setToastMessage] = useState("");

  const recruitmentsList = [
    {
      id: "rec-1",
      clubId: "club-1",
      clubName: "Technical Club",
      role: "Core Team Recruitment",
      category: "Technical",
      tags: ["Web Dev", "Design", "Content", "Event Management"],
      description: "Join the technical core team organizing campus hackathons, open-source projects, and hands-on developer workshops.",
      daysLeft: "Ends in 5 days",
      deadline: "Nov 5, 2026",
      status: "Open",
      applicantsCount: 42,
      icon: Zap,
      iconBg: "bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-[#D2F863]",
    },
    {
      id: "rec-2",
      clubId: "club-1",
      clubName: "Technical Club",
      role: "General Member Recruitment",
      category: "Technical",
      tags: ["Open for all branches", "No prerequisite"],
      description: "Become an official member of the campus tech chapter. Access study cohorts, tech talks, and project pairing.",
      daysLeft: "Ends in 10 days",
      deadline: "Nov 10, 2026",
      status: "Open",
      applicantsCount: 68,
      icon: Users,
      iconBg: "bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-[#D2F863]",
    },
    {
      id: "rec-3",
      clubId: "club-14",
      clubName: "Growth Pulse Marketing",
      role: "General Member & PR Associate",
      category: "Marketing",
      tags: ["Social Media", "PR", "Sponsorships"],
      description: "Drive campus outreach, negotiate industry sponsorships, and manage social media campaigns for flagship events.",
      daysLeft: "Ends in 7 days",
      deadline: "Nov 7, 2026",
      status: "Open",
      applicantsCount: 29,
      icon: Megaphone,
      iconBg: "bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400",
    },
    {
      id: "rec-4",
      clubId: "club-4",
      clubName: "Design Guild",
      role: "UI/UX Apprentice & Visual Lead",
      category: "Media & Design",
      tags: ["Figma", "Branding", "Asset Creation"],
      description: "Collaborate on university design systems, student magazine layouts, and event merchandise branding.",
      daysLeft: "Ends in 4 days",
      deadline: "Nov 4, 2026",
      status: "Open",
      applicantsCount: 35,
      icon: Palette,
      iconBg: "bg-purple-100 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400",
    },
    {
      id: "rec-5",
      clubId: "club-2",
      clubName: "Robotics & Autonomous Systems",
      role: "Hardware & Sensor Lab Associate",
      category: "Technical",
      tags: ["Embedded C", "IoT", "Fabrication"],
      description: "Work on competitive combat bots, autonomous delivery drones, and micro-controller sensor rigs.",
      daysLeft: "Ends in 8 days",
      deadline: "Nov 8, 2026",
      status: "Open",
      applicantsCount: 24,
      icon: Bot,
      iconBg: "bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400",
    },
    {
      id: "rec-6",
      clubId: "club-3",
      clubName: "Symphony Cultural Club",
      role: "Stage Performance & Audio Production",
      category: "Cultural",
      tags: ["Vocals", "Instrumental", "Sound Engineering"],
      description: "Perform at inter-college fests, organize campus open-mic nights, and manage auditorium sound productions.",
      daysLeft: "Ends in 6 days",
      deadline: "Nov 6, 2026",
      status: "Open",
      applicantsCount: 51,
      icon: Music,
      iconBg: "bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400",
    },
    {
      id: "rec-7",
      clubId: "club-6",
      clubName: "University Football & Athletics Club",
      role: "Varsity Striker & Athletic Squad",
      category: "Sports",
      tags: ["Football", "Track & Field", "Fitness Drills"],
      description: "Join the varsity athletic and football team competing in the Inter-University Championship and weekend branch leagues.",
      daysLeft: "Ends in 9 days",
      deadline: "Nov 12, 2026",
      status: "Open",
      applicantsCount: 62,
      icon: Trophy,
      iconBg: "bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400",
    },
    {
      id: "rec-8",
      clubId: "club-7",
      clubName: "Hoops Basketball League",
      role: "Varsity Point Guard & Referee",
      category: "Sports",
      tags: ["Basketball", "3v3 Intramural", "Refereeing"],
      description: "Trial for the men's and women's campus basketball squads and officiate weekend floodlit court matchups.",
      daysLeft: "Ends in 11 days",
      deadline: "Nov 15, 2026",
      status: "Open",
      applicantsCount: 38,
      icon: Trophy,
      iconBg: "bg-orange-100 dark:bg-orange-950/60 text-orange-600 dark:text-orange-400",
    },
    {
      id: "rec-9",
      clubId: "club-10",
      clubName: "ShutterSpeed Photography",
      role: "Event Cinematographer & Drone Pilot",
      category: "Photography",
      tags: ["Drone", "Editorial", "Lightroom"],
      description: "Cover live campus festivals, edit documentary shorts, and master aerial cinematography for university media.",
      daysLeft: "Ends in 8 days",
      deadline: "Nov 11, 2026",
      status: "Open",
      applicantsCount: 45,
      icon: Camera,
      iconBg: "bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400",
    },
    {
      id: "rec-10",
      clubId: "club-12",
      clubName: "GreenCampus Eco Movement",
      role: "Campus Sustainability Ambassador",
      category: "Social Service",
      tags: ["Tree Plantation", "Zero Waste", "Advocacy"],
      description: "Lead university-wide environmental campaigns, composting hubs, and native biodiversity preservation projects.",
      daysLeft: "Ends in 5 days",
      deadline: "Nov 7, 2026",
      status: "Open",
      applicantsCount: 56,
      icon: Compass,
      iconBg: "bg-teal-100 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400",
    },
  ];

  const filtered = recruitmentsList.filter((item) => {
    const matchesCat = selectedCategory === "All" || item.category === selectedCategory;
    const matchesSearch =
      item.clubName.toLowerCase().includes(search.toLowerCase()) ||
      item.role.toLowerCase().includes(search.toLowerCase()) ||
      item.tags.some((t) => t.toLowerCase().includes(search.toLowerCase()));
    return matchesCat && matchesSearch;
  });

  const handleApplyClick = (item) => {
    setSelectedClub({ id: item.clubId, name: item.clubName });
    setSelectedRole(item.role);
    setIsModalOpen(true);
  };

  const handleApplySuccess = () => {
    setToastMessage("Application submitted! Check status in your Student Dashboard.");
    setTimeout(() => setToastMessage(""), 4500);
  };

  return (
    <div className="bg-[#F2F4F8] dark:bg-[#030108] text-slate-900 dark:text-slate-100 min-h-screen py-8 pb-20 transition-colors duration-300">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-20 right-6 z-50 bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-xs font-semibold shadow-xl flex items-center gap-2 animate-in fade-in slide-in-from-top">
          <CheckCircle2 className="h-4 w-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-8">
        {/* Top Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-4 border-b border-slate-200 dark:border-white/10">
          <div>
            <div className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 dark:bg-white/10 px-3 py-1 text-xs font-semibold text-blue-600 dark:text-[#D2F863] border border-blue-200 dark:border-white/10 mb-2">
              <Briefcase className="h-3.5 w-3.5" />
              <span>Campus Recruitment Portals</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
              Open Club Recruitments
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-1">
              Apply to join core teams, executive boards, and general member cohorts for the current semester.
            </p>
          </div>

          <Link
            href="/dashboard/student"
            className="text-xs font-bold text-blue-600 dark:text-[#D2F863] hover:underline inline-flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Back to Dashboard</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-[#14151B] border border-slate-200/90 dark:border-white/10 shadow-xs transition-colors">
          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
            {["All", "Technical", "Marketing", "Media & Design", "Cultural"].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  selectedCategory === cat
                    ? "bg-blue-600 text-white shadow-2xs"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-white/10 hover:text-slate-900 dark:hover:text-white"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by club, role, track..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-[#1C1E26] border border-slate-200 dark:border-white/10 rounded-xl text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
          </div>
        </div>

        {/* Recruitments Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filtered.map((item) => {
            const IconComp = item.icon;
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-[#14151B] rounded-3xl border border-slate-200/90 dark:border-white/10 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${item.iconBg}`}>
                        <IconComp className="h-6 w-6" />
                      </div>
                      <div>
                        <span className="text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wide">
                          {item.clubName}
                        </span>
                        <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight mt-0.5">
                          {item.role}
                        </h3>
                      </div>
                    </div>

                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-900/50 shrink-0">
                      {item.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                    {item.description}
                  </p>

                  {/* Track Tags */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {item.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-0.5 rounded-lg text-[10px] font-semibold bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium">
                    <Clock className="h-3.5 w-3.5 text-slate-400 dark:text-slate-500" />
                    <span>{item.daysLeft}</span>
                    <span className="text-slate-300 dark:text-slate-600">•</span>
                    <span>{item.applicantsCount} applicants</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleApplyClick(item)}
                    style={{ backgroundColor: "#F37021", color: "#FFFFFF" }}
                    className="px-4 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold transition-all shadow-xs active:scale-95 flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Apply Now</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <ApplyClubModal
        club={selectedClub}
        initialRole={selectedRole}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSuccess={handleApplySuccess}
      />
    </div>
  );
}
