"use client";
import React, { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import {
  GraduationCap,
  Shield,
  ArrowRight,
  ChevronRight,
  Sparkles,
  Mail,
  Lock,
  User,
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle2,
  Building2,
  Calendar,
  Loader2,
} from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";

// Official 4-color Google Icon
function GoogleIcon({ className = "h-5 w-5" }) {
  return (
    <svg className={className} viewBox="0 0 24 24">
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
      />
    </svg>
  );
}

const DEPARTMENTS = [
  "Computer Science & Engineering",
  "Electrical & Electronics Engineering",
  "School of Design & Media Arts",
  "School of Management & Business",
  "Mechanical & Robotics Engineering",
  "Biotechnology & Health Sciences",
  "Humanities & Social Sciences",
];

const YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year", "Postgraduate / Alumni"];

function SignupContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectParam = searchParams.get("redirect");
  const roleParam = searchParams.get("role");

  const { isDark } = useTheme();
  const { loginWithFirebaseGoogle, registerWithFirebaseEmail } = useAuth();

  // Role: "student" | "admin"
  const [selectedRole, setSelectedRole] = useState(
    roleParam === "admin" ? "admin" : "student"
  );

  // Form State
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [department, setDepartment] = useState(DEPARTMENTS[0]);
  const [year, setYear] = useState(YEARS[1]);

  // Loading & Feedback
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleRouteRedirect = (role) => {
    if (redirectParam) {
      router.push(redirectParam);
      return;
    }
    const targetRole = role || selectedRole;
    if (targetRole === "admin") {
      router.push("/dashboard/admin");
    } else if (targetRole === "leader") {
      router.push("/dashboard/leader");
    } else {
      router.push("/dashboard/student");
    }
  };

  // Google Sign-up
  const handleGoogleSignUp = async () => {
    setErrorMessage("");
    setSuccessMessage("");
    setIsGoogleLoading(true);

    try {
      const result = await loginWithFirebaseGoogle(selectedRole);
      setSuccessMessage(result.message || `Signed in with Google as ${result.user.name}`);
      const targetRole = result.user?.role || selectedRole;
      setTimeout(() => {
        handleRouteRedirect(targetRole);
      }, 700);
    } catch (err) {
      setErrorMessage(err.message || "Google authentication failed. Please try again.");
    } finally {
      setIsGoogleLoading(false);
    }
  };

  // Email & Password Registration
  const handleRegister = async (e) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    if (!name.trim()) {
      setErrorMessage("Please enter your full name.");
      return;
    }

    if (!email.trim() || !email.includes("@")) {
      setErrorMessage("Please enter a valid campus or personal email address.");
      return;
    }

    if (!password || password.length < 6) {
      setErrorMessage("Password must be at least 6 characters long.");
      return;
    }

    setIsLoading(true);

    try {
      const result = await registerWithFirebaseEmail({
        name: name.trim(),
        email: email.trim(),
        password,
        department,
        year: selectedRole === "admin" ? "Faculty / Staff" : year,
        role: selectedRole,
        bio:
          selectedRole === "admin"
            ? "Campus administration coordinator."
            : "Active campus club contributor and student.",
      });

      setSuccessMessage(
        `Welcome to ClubPulse, ${result.user.name}! Your account is ready. Redirecting...`
      );
      const targetRole = result.user?.role || selectedRole;
      setTimeout(() => {
        handleRouteRedirect(targetRole);
      }, 700);
    } catch (err) {
      setErrorMessage(
        err.message || "Failed to create account. Please check your details and try again."
      );
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen md:h-screen md:max-h-screen w-full flex flex-col md:flex-row bg-[#EDF1F7] dark:bg-[#060911] transition-colors duration-300 md:overflow-hidden">
      {/* LEFT COLUMN: Campus Photography Hero */}
      <div className="relative w-full md:w-5/12 lg:w-1/2 min-h-[260px] sm:min-h-[300px] md:h-full flex flex-col justify-between p-6 sm:p-8 lg:p-12 overflow-hidden shrink-0">
        <div
          className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 scale-105"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=1600&auto=format&fit=crop&q=80')`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-slate-950/40" />

        {/* Top Brand Logo */}
        <div className="relative z-10 flex items-center gap-3">
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-2xl bg-[#F37021] flex items-center justify-center text-white shadow-lg shadow-orange-500/30 group-hover:scale-105 transition-transform">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-white leading-tight">
                Club<span className="text-[#F37021]">Pulse</span>
              </h1>
              <p className="text-[11px] font-medium tracking-wide text-blue-200 uppercase">
                Discover · Join · Contribute
              </p>
            </div>
          </Link>
        </div>

        {/* Bottom Inspiring Typography */}
        <div className="relative z-10 max-w-lg mt-auto pt-6 md:pt-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white/90 text-xs font-semibold mb-4">
            <Sparkles className="h-3.5 w-3.5 text-blue-300" />
            <span>Join 2,400+ University Members</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight leading-tight space-y-0.5">
            <span className="block">Start Your Campus</span>
            <span className="block text-blue-300">Leadership Journey</span>
            <span className="block text-slate-200">With Verifiable Proof.</span>
          </h2>
          <p className="mt-3 text-xs sm:text-sm text-slate-300/90 leading-relaxed font-normal">
            Create an official ClubPulse account to join student clubs, collaborate on campus events, earn verified contribution certificates, and keep leadership transparent.
          </p>
        </div>
      </div>

      {/* RIGHT COLUMN: Dedicated Signup Card */}
      <div className="w-full md:w-7/12 lg:w-1/2 md:h-full flex flex-col items-center p-4 sm:p-6 lg:p-8 bg-[#EDF1F7] dark:bg-[#060911] relative transition-colors duration-300 overflow-y-auto justify-start md:justify-center py-6 sm:py-8">
        {/* Top-Right Theme Toggle */}
        <div className="absolute top-4 right-4 sm:top-6 sm:right-6 z-20">
          <ThemeToggle />
        </div>

        {/* Floating Card */}
        <div className="w-full max-w-[460px] my-auto rounded-[24px] sm:rounded-[28px] bg-white dark:bg-[#0A0E1A] border border-slate-200 dark:border-blue-950/70 p-5 sm:p-6 shadow-xl sm:shadow-2xl shadow-slate-300/50 dark:shadow-black/80 backdrop-blur-xl relative transition-all duration-300 shrink-0">
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-600/10 via-cyan-500/10 to-blue-600/10 rounded-[34px] blur-xl -z-10 pointer-events-none" />

          {/* Header */}
          <div className="text-left mb-4">
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-tight">
              Create an account
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm mt-1 font-normal">
              Get started with ClubPulse in seconds.
            </p>
          </div>

          {/* Feedback Alerts */}
          {errorMessage && (
            <div className="mb-4 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-600 dark:text-rose-300 flex items-center gap-2.5 animate-in fade-in">
              <AlertCircle className="h-4 w-4 shrink-0 text-rose-500 dark:text-rose-400" />
              <span className="leading-snug">{errorMessage}</span>
            </div>
          )}
          {successMessage && (
            <div className="mb-4 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2.5 animate-in fade-in">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <span className="leading-snug">{successMessage}</span>
            </div>
          )}

          {/* Role Selection Tabs */}
          <div className="grid grid-cols-2 gap-2.5 mb-3.5">
            <button
              type="button"
              onClick={() => setSelectedRole("student")}
              className={`p-2.5 rounded-xl text-left transition-all cursor-pointer flex items-center gap-2 ${
                selectedRole === "student"
                  ? "border-2 border-blue-500 bg-blue-50 dark:bg-[#0E1A33] shadow-md shadow-blue-500/20 ring-1 ring-blue-500/40"
                  : "border border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-[#0B0F19] hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#0E1322]"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                  selectedRole === "student"
                    ? "bg-blue-600 text-white shadow-sm shadow-blue-500/30"
                    : "bg-slate-200 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400"
                }`}
              >
                <GraduationCap className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">
                  Student Member
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5 leading-tight truncate">
                  Join clubs & track tasks
                </span>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setSelectedRole("admin")}
              className={`p-2.5 rounded-xl text-left transition-all cursor-pointer flex items-center gap-2 ${
                selectedRole === "admin"
                  ? "border-2 border-blue-500 bg-blue-50 dark:bg-[#0E1A33] shadow-md shadow-blue-500/20 ring-1 ring-blue-500/40"
                  : "border border-slate-200 dark:border-slate-800/80 bg-slate-50 dark:bg-[#0B0F19] hover:border-slate-300 dark:hover:border-slate-700 hover:bg-slate-100 dark:hover:bg-[#0E1322]"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 transition-colors ${
                  selectedRole === "admin"
                    ? "bg-blue-600 text-white shadow-sm shadow-blue-500/30"
                    : "bg-slate-200 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400"
                }`}
              >
                <Shield className="h-4 w-4" />
              </div>
              <div className="min-w-0">
                <span className="text-xs font-bold text-slate-900 dark:text-white block truncate">
                  Dean / Admin
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block mt-0.5 leading-tight truncate">
                  Governance & audit
                </span>
              </div>
            </button>
          </div>

          {/* Quick Sign-up with Google */}
          <button
            type="button"
            onClick={handleGoogleSignUp}
            disabled={isGoogleLoading}
            className="w-full py-2.5 px-3.5 rounded-xl bg-slate-50 dark:bg-[#0D1220] hover:bg-slate-100 dark:hover:bg-[#12182B] border border-slate-200 dark:border-slate-800/90 hover:border-slate-300 dark:hover:border-slate-700 flex items-center justify-between transition-all group cursor-pointer shadow-xs active:scale-[0.99] disabled:opacity-50 mb-3.5"
          >
            <div className="flex items-center gap-3">
              {isGoogleLoading ? (
                <Loader2 className="h-5 w-5 text-blue-500 animate-spin" />
              ) : (
                <GoogleIcon className="h-5 w-5" />
              )}
            </div>
            <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-white text-center flex-1">
              {isGoogleLoading ? "Connecting to Google..." : "Sign up with Google"}
            </span>
            <ChevronRight className="h-4 w-4 text-slate-400 group-hover:text-slate-700 dark:group-hover:text-white transition-colors" />
          </button>

          {/* Divider */}
          <div className="relative my-3 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200 dark:border-slate-800/80" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-white dark:bg-[#0A0E1A] px-3 text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500 select-none">
                OR REGISTER WITH CAMPUS EMAIL
              </span>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleRegister} className="space-y-3">
            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Full Name
              </label>
              <div className="relative">
                <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex Morgan"
                  required
                  className="w-full pl-10 pr-3.5 py-2 sm:py-2.5 rounded-xl bg-slate-50 dark:bg-[#0B101D] border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Campus Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex.m@campus.edu"
                  required
                  autoComplete="email"
                  className="w-full pl-10 pr-3.5 py-2 sm:py-2.5 rounded-xl bg-slate-50 dark:bg-[#0B101D] border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimum 6 characters"
                  required
                  autoComplete="new-password"
                  className="w-full pl-10 pr-10 py-2 sm:py-2.5 rounded-xl bg-slate-50 dark:bg-[#0B101D] border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors cursor-pointer"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Academic School / Department & Year */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-0.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  Department
                </label>
                <div className="relative">
                  <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-[#0B101D] border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
                  >
                    {DEPARTMENTS.map((dept) => (
                      <option key={dept} value={dept}>
                        {dept}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-200 mb-1">
                  {selectedRole === "admin" ? "Designation" : "Academic Year"}
                </label>
                <div className="relative">
                  <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
                  <select
                    value={year}
                    onChange={(e) => setYear(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-[#0B101D] border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500 transition-colors cursor-pointer"
                  >
                    {YEARS.map((y) => (
                      <option key={y} value={y}>
                        {y}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-4 py-2.5 sm:py-3 px-4 rounded-xl bg-[#00E599] hover:bg-[#00D48D] text-slate-950 font-black text-sm tracking-wide shadow-lg shadow-[#00E599]/20 transition-all active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin text-slate-950" />
                  <span>Creating Account...</span>
                </>
              ) : (
                <>
                  <span>Create Account</span>
                  <ArrowRight className="h-4 w-4 stroke-[2.5]" />
                </>
              )}
            </button>
          </form>

          {/* Switch to Login Link */}
          <div className="text-center mt-5 text-xs text-slate-500 dark:text-slate-400">
            Already have an account?{" "}
            <Link
              href="/login"
              className="text-blue-600 dark:text-blue-400 hover:underline font-bold transition-colors cursor-pointer ml-1"
            >
              Sign In
            </Link>
          </div>

          {/* Security footnote */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-white/5 text-center text-[10px] text-slate-400 dark:text-slate-500">
            Protected by university SSO & role-based authentication.
          </div>
        </div>
      </div>
    </div>
  );
}

export default function SignupPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-[#EDF1F7] dark:bg-[#060911] text-xs text-slate-400">
          Loading sign up portal...
        </div>
      }
    >
      <SignupContent />
    </Suspense>
  );
}

