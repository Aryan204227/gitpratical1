import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function POST(request) {
    try {
        const body = await request.json();
        const { userId, clubId, reason, endDate } = body;
        if (!userId || !clubId || !reason || !endDate) {
            return NextResponse.json({ success: false, error: "Missing required break request details (reason, endDate)" }, { status: 400 });
        }
        const updated = db.requestLeaveOfAbsence(userId, clubId, reason, endDate);
        if (!updated) {
            return NextResponse.json({ success: false, error: "Membership not found for this club" }, { status: 404 });
        }
        return NextResponse.json({
            success: true,
            message: "Temporary break approved and recorded. You will not be flagged as inactive.",
            membership: updated,
        });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to process break request" }, { status: 500 });
    }
}
