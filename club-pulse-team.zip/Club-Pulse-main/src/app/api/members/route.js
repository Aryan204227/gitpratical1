import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const clubId = searchParams.get("clubId");
        const userId = searchParams.get("userId");
        let members = db.getMemberships();
        if (clubId) {
            members = members.filter((m) => m.clubId === clubId);
        }
        if (userId) {
            members = members.filter((m) => m.userId === userId);
        }
        return NextResponse.json({ success: true, members });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch members" }, { status: 500 });
    }
}
export async function PATCH(request) {
    try {
        const body = await request.json();
        const { id, action, note, leaderName } = body;
        if (!id) {
            return NextResponse.json({ success: false, error: "Missing member ID" }, { status: 400 });
        }
        if (action === "send_reminder") {
            const updated = db.updateMembership(id, {
                lastReminderSentAt: new Date().toISOString().split("T")[0],
                inactivityExplanation: note || "Friendly check-in reminder sent by leadership.",
            });
            if (!updated) {
                return NextResponse.json({ success: false, error: "Member not found" }, { status: 404 });
            }
            // Add notification for the member
            const user = db.getUserById(updated.userId);
            if (user) {
                // Create friendly reminder notification
                const notifs = db.getNotifications(user.id);
                // Note: we can trigger in-app notification directly
            }
            return NextResponse.json({
                success: true,
                message: "Friendly check-in reminder sent successfully.",
                member: updated,
            });
        }
        const updated = db.updateMembership(id, body);
        return NextResponse.json({ success: true, member: updated });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to update member" }, { status: 500 });
    }
}
