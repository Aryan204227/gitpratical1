import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { initialUsers } from "@/lib/seedData";

/**
 * Checks if an email is authorized for Admin / Dean access through trusted backend process
 */
function isAuthorizedAdmin(email) {
  if (!email) return false;
  const normalized = email.trim().toLowerCase();

  // 1. Check environment variable list of authorized admin emails
  const envAdminEmails = (process.env.ADMIN_EMAILS || "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);

  if (envAdminEmails.includes(normalized)) {
    return true;
  }

  // 2. Pre-seeded university dean/admin emails (e.g., Prof. Marcus Vance / Dean's Office)
  const defaultAdminEmails = [
    "marcus.vance@campus.edu",
    "dean@campus.edu",
    "admin@campus.edu",
    "office.student.affairs@campus.edu",
    "dean.admin@campus.edu",
  ];

  if (defaultAdminEmails.includes(normalized)) {
    return true;
  }

  return false;
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { idToken, email, name, avatar, uid, year, department, bio, requestedRole, role } = body;

    if (!email) {
      return NextResponse.json(
        { success: false, error: "An authenticated email address is required." },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();

    // 1. Look up existing user before determining role
    let existingUser =
      (typeof db?.getUserByEmail === "function"
        ? db.getUserByEmail(normalizedEmail)
        : null) ||
      (typeof db?.getUsers === "function"
        ? db.getUsers().find((u) => u.email?.toLowerCase() === normalizedEmail)
        : null) ||
      initialUsers.find((u) => u.email?.toLowerCase() === normalizedEmail);
    
    // Determine assigned role:
    // If the user selected a specific role on the UI (e.g. "student" or "admin"), honor that selection!
    const rolePref = requestedRole || role;
    let assignedRole = "student";
    if (rolePref === "student") {
      assignedRole = "student";
    } else if (rolePref === "admin") {
      assignedRole = "admin";
    } else if (isAuthorizedAdmin(normalizedEmail)) {
      assignedRole = "admin";
    } else if (existingUser?.role) {
      assignedRole = existingUser.role;
    }

    // Format display name dynamically based on Google Account name and role
    const rawName = (name && name.trim()) || normalizedEmail.split("@")[0];
    const cleanBaseName = rawName.replace(/^(Dean|Prof\.|Dr\.)\s+/i, "").trim() || "User";
    const finalDisplayName = assignedRole === "admin"
      ? (rawName.startsWith("Dean") ? rawName : `Dean ${cleanBaseName}`)
      : cleanBaseName;

    let activeUser = null;
    let isNewUser = false;

    if (existingUser) {
      // User already exists: update name to reflect Google Account name, role, and last login
      const updates = {
        name: finalDisplayName,
        role: assignedRole,
        lastLoginAt: new Date().toISOString(),
      };

      if (avatar && (!existingUser.avatar || existingUser.avatar.includes("default"))) {
        updates.avatar = avatar;
      }
      if (uid && !existingUser.firebaseUid) {
        updates.firebaseUid = uid;
      }

      if (typeof db?.updateUser === "function") {
        activeUser = db.updateUser(existingUser.id, updates) || { ...existingUser, ...updates };
      } else {
        activeUser = { ...existingUser, ...updates };
      }
    } else {
      // New user registration
      isNewUser = true;

      const defaultAvatars = {
        student:
          "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
        admin:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
      };

      const userAvatar =
        avatar ||
        defaultAvatars[assignedRole] ||
        `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`;

      activeUser = db.createUser({
        name: finalDisplayName,
        email: normalizedEmail,
        password: `firebase_auth_${Date.now()}`,
        role: assignedRole,
        department: department || (assignedRole === "admin" ? "Office of Student Affairs" : "General Studies"),
        year: year || (assignedRole === "admin" ? "Faculty / Dean" : "1st Year"),
        bio: bio || (assignedRole === "admin" ? "Dean of Student Affairs overseeing campus clubs." : "Campus community member."),
        avatar: userAvatar,
        firebaseUid: uid || `fb_${Date.now()}`,
        clubsJoined: [],
      });
    }

    // Role-based destination:
    // Students -> /dashboard/student
    // Authorized Admins -> /dashboard/admin
    const redirectUrl =
      activeUser.role === "admin" ? "/dashboard/admin" : "/dashboard/student";

    const response = NextResponse.json({
      success: true,
      authenticated: true,
      isNewUser,
      role: activeUser.role,
      redirectUrl,
      user: {
        id: activeUser.id,
        name: activeUser.name,
        email: activeUser.email,
        role: activeUser.role,
        avatar: activeUser.avatar,
        department: activeUser.department,
        year: activeUser.year,
        bio: activeUser.bio,
        clubsJoined: activeUser.clubsJoined || [],
      },
      message: isNewUser
        ? `Account registered successfully! Welcome to ClubPulse, ${activeUser.name}.`
        : `Welcome back, ${activeUser.name}!`,
    });

    // Set secure authentication cookies for session persistence and SSR protection (Unit IV)
    response.cookies.set("clubpulse_user_id", activeUser.id, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    response.cookies.set("clubpulse_session_role", activeUser.role, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("clubpulse_role", activeUser.role, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("active_persona", activeUser.role, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("clubpulse_token", `token_${activeUser.id}_${Date.now()}`, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error) {
    console.error("Firebase sync error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to synchronize authentication session." },
      { status: 500 }
    );
  }
}
