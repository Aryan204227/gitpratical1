import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { initialUsers } from "@/lib/seedData";

export async function GET(request) {
  try {
    const cookieUserId = request.cookies.get("clubpulse_user_id")?.value;
    const url = new URL(request.url);
    const queryUserId = url.searchParams.get("userId");

    const userId = cookieUserId || queryUserId;
    if (!userId) {
      return NextResponse.json(
        { success: false, authenticated: false, user: null },
        { status: 200 }
      );
    }

    const user = db.getUserById(userId) || initialUsers.find((u) => u.id === userId);
    if (!user) {
      return NextResponse.json(
        { success: false, authenticated: false, user: null },
        { status: 200 }
      );
    }

    return NextResponse.json({
      success: true,
      authenticated: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        department: user.department,
        year: user.year,
        bio: user.bio,
        clubsJoined: user.clubsJoined || [],
      },
    });
  } catch (error) {
    if (error?.digest === "NEXT_PRERENDER_INTERRUPTED") {
      throw error;
    }
    console.error("Auth me check error:", error);
    return NextResponse.json(
      { success: false, authenticated: false, error: "Failed to verify session" },
      { status: 500 }
    );
  }
}
