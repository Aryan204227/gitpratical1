import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { initialUsers } from "@/lib/seedData";

export async function POST(request) {
  try {
    const body = await request.json();
    let { email, name, avatar, role, department, year, credential } = body;

    // 1. If Google Identity Services JWT credential is provided, decode payload
    if (credential && typeof credential === "string") {
      try {
        const parts = credential.split(".");
        if (parts.length === 3) {
          const payloadBase64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
          const decodedJson = Buffer.from(payloadBase64, "base64").toString("utf-8");
          const payload = JSON.parse(decodedJson);
          if (payload.email) email = payload.email;
          if (payload.name) name = payload.name;
          if (payload.picture) avatar = payload.picture;
        }
      } catch (decodeErr) {
        console.warn("Could not decode Google ID token credential:", decodeErr);
      }
    }

    if (!email) {
      return NextResponse.json(
        { success: false, error: "A valid Google account email is required." },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();
    const displayName = (name && name.trim()) || normalizedEmail.split("@")[0];

    // Backend authorized admin check
    const envAdminEmails = (process.env.ADMIN_EMAILS || "")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);
    const defaultAdminEmails = ["marcus.vance@campus.edu", "dean@campus.edu", "admin@campus.edu"];
    const isAuthorizedAdmin =
      envAdminEmails.includes(normalizedEmail) || defaultAdminEmails.includes(normalizedEmail);

    const assignedRole = role === "admin" || isAuthorizedAdmin ? "admin" : "student";

    // Format display name based on Google Account name and role
    const cleanBaseName = displayName.replace(/^(Dean|Prof\.|Dr\.)\s+/i, "").trim() || "User";
    const finalDisplayName = assignedRole === "admin"
      ? (displayName.startsWith("Dean") ? displayName : `Dean ${cleanBaseName}`)
      : cleanBaseName;

    // 2. Check if user already exists in db store or seed
    let existingUser =
      (typeof db?.getUserByEmail === "function"
        ? db.getUserByEmail(normalizedEmail)
        : null) ||
      (typeof db?.getUsers === "function"
        ? db.getUsers().find((u) => u.email?.toLowerCase() === normalizedEmail)
        : null) ||
      initialUsers.find((u) => u.email?.toLowerCase() === normalizedEmail);

    let activeUser = null;
    let isNew = false;

    if (existingUser) {
      // User exists - update name to Google account name and sync role
      const updates = {
        name: finalDisplayName,
        role: assignedRole,
        authProvider: "google",
      };
      if (avatar && (!existingUser.avatar || existingUser.avatar.includes("default"))) {
        updates.avatar = avatar;
      }

      if (typeof db?.updateUser === "function") {
        activeUser = db.updateUser(existingUser.id, updates) || { ...existingUser, ...updates };
      } else {
        activeUser = { ...existingUser, ...updates };
      }
    } else {
      // User is registering for the first time with Google
      isNew = true;
      const defaultAvatars = {
        student:
          "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
        leader:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
        admin:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
      };

      const userAvatar =
        avatar ||
        defaultAvatars[assignedRole] ||
        `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`;

      activeUser = db.createUser({
        name: finalDisplayName,
        email: normalizedEmail,
        password: `google_oauth_${Date.now()}`,
        role: assignedRole,
        department: department || (assignedRole === "admin" ? "Office of Student Affairs" : "General Studies"),
        year: year || (assignedRole === "admin" ? "Faculty / Dean" : "1st Year"),
        bio: assignedRole === "admin" ? "Dean of Student Affairs overseeing campus clubs." : "Member registered directly with Google Account.",
        avatar: userAvatar,
        clubsJoined: [],
        authProvider: "google",
      });
    }

    const response = NextResponse.json({
      success: true,
      authenticated: true,
      isNew,
      message: isNew
        ? `Google registration complete! Welcome to ClubPulse, ${activeUser.name}.`
        : `Welcome back, ${activeUser.name}! Signed in via Google.`,
      user: {
        id: activeUser.id,
        name: activeUser.name,
        email: activeUser.email,
        role: activeUser.role,
        avatar: activeUser.avatar,
        department: activeUser.department,
        year: activeUser.year,
        bio: activeUser.bio,
        clubsJoined: activeUser.clubsJoined || [],
        authProvider: "google",
      },
    });

    response.cookies.set("clubpulse_user_id", activeUser.id, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    response.cookies.set("clubpulse_session_role", activeUser.role, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("clubpulse_token", `token_${activeUser.id}_${Date.now()}`, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error) {
    console.error("Google authentication error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to authenticate with Google." },
      { status: 500 }
    );
  }
}
