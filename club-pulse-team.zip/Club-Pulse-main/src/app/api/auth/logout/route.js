import { NextResponse } from "next/server";

export async function POST() {
  const response = NextResponse.json({
    success: true,
    message: "Logged out successfully",
  });

  response.cookies.delete("clubpulse_user_id");
  response.cookies.delete("clubpulse_session_role");
  response.cookies.delete("clubpulse_token");
  response.cookies.delete("clubpulse_role");
  response.cookies.delete("auth_token");
  response.cookies.delete("active_persona");

  return response;
}
