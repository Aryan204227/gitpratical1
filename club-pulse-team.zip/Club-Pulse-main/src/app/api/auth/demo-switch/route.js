import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { initialUsers } from "@/lib/seedData";

export async function POST(request) {
  try {
    const body = await request.json().catch(() => ({}));
    const { userId, role, currentUserId, email } = body;

    let targetUser = null;

    // Check if the current authenticated user wants to switch their role (e.g. Google student user switching to admin)
    const activeUserId = currentUserId || request.cookies.get("clubpulse_user_id")?.value;
    const activeUserEmail = email ? email.trim().toLowerCase() : null;

    let currentUser = null;
    if (activeUserId) {
      currentUser = typeof db?.getUserById === "function" ? db.getUserById(activeUserId) : null;
    }
    if (!currentUser && activeUserEmail) {
      currentUser = typeof db?.getUserByEmail === "function" ? db.getUserByEmail(activeUserEmail) : null;
    }

    if (currentUser && role) {
      // Elevate or switch current active user's role in the DB, preserving their Google account name
      const cleanBaseName = currentUser.name.replace(/^(Dean|Prof\.|Dr\.)\s+/i, "").trim() || "User";
      const dynamicName = role.toLowerCase() === "admin" ? `Dean ${cleanBaseName}` : cleanBaseName;
      
      const updatedUser = typeof db?.updateUser === "function"
        ? db.updateUser(currentUser.id, { role: role.toLowerCase(), name: dynamicName })
        : { ...currentUser, role: role.toLowerCase(), name: dynamicName };
      targetUser = updatedUser || currentUser;
    } else if (userId) {
      targetUser =
        (typeof db?.getUserById === "function" ? db.getUserById(userId) : null) ||
        initialUsers.find((u) => u.id === userId);
    } else if (role) {
      const roleMap = {
        student: "user-1", // Alex Rivera
        leader: "user-2",  // Sarah Chen
        admin: "user-3",   // Prof. Marcus Vance
      };
      const mappedId = roleMap[role.toLowerCase()] || "user-3";
      targetUser =
        (typeof db?.getUserById === "function" ? db.getUserById(mappedId) : null) ||
        initialUsers.find((u) => u.id === mappedId);
    }

    if (!targetUser) {
      targetUser = initialUsers[2] || initialUsers[0];
    }

    const safeUser = {
      id: targetUser.id,
      name: targetUser.name,
      email: targetUser.email,
      role: targetUser.role,
      avatar: targetUser.avatar,
      department: targetUser.department,
      year: targetUser.year,
      bio: targetUser.bio,
      clubsJoined: targetUser.clubsJoined || [],
    };

    const response = NextResponse.json({
      success: true,
      user: safeUser,
      message: `Switched active session to ${safeUser.name} (${safeUser.role})`,
    });

    response.cookies.set("clubpulse_user_id", safeUser.id, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    response.cookies.set("clubpulse_session_role", safeUser.role, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("clubpulse_token", `token_${safeUser.id}_${Date.now()}`, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error) {
    console.error("Demo switch error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to switch persona" },
      { status: 500 }
    );
  }
}
