import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(request) {
  try {
    const body = await request.json();
    const { name, email, password, role, department, year, bio } = body;

    if (!name || !email || !password) {
      return NextResponse.json(
        { success: false, error: "Please fill in name, email, and password." },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { success: false, error: "Password must be at least 6 characters long." },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing =
      (typeof db?.getUserByEmail === "function"
        ? db.getUserByEmail(normalizedEmail)
        : null) ||
      (typeof db?.getUsers === "function"
        ? db.getUsers().find((u) => u.email?.toLowerCase() === normalizedEmail)
        : null);
    if (existing) {
      return NextResponse.json(
        { success: false, error: "An account with this campus email already exists." },
        { status: 409 }
      );
    }

    // Role-based avatar assignment if none provided
    const defaultAvatars = {
      student: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
      leader: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
      admin: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    };

    // Check backend admin authorization list or explicit role selection
    const envAdminEmails = (process.env.ADMIN_EMAILS || "")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);
    const defaultAdminEmails = ["marcus.vance@campus.edu", "dean@campus.edu", "admin@campus.edu"];
    const isAuthorizedAdmin =
      envAdminEmails.includes(normalizedEmail) || defaultAdminEmails.includes(normalizedEmail);

    // Respect requested role (admin, student, or leader)
    const assignedRole = role === "admin" || isAuthorizedAdmin ? "admin" : (role || "student");

    const newUser = db.createUser({
      name: name.trim(),
      email: normalizedEmail,
      password,
      role: assignedRole,
      department: department || "General Studies",
      year: year || "1st Year",
      bio: bio || "Passionate about campus activities and peer collaboration.",
      avatar: defaultAvatars[assignedRole] || defaultAvatars.student,
      clubsJoined: [],
    });

    const response = NextResponse.json({
      success: true,
      user: {
        id: newUser.id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role,
        avatar: newUser.avatar,
        department: newUser.department,
        year: newUser.year,
        bio: newUser.bio,
        clubsJoined: newUser.clubsJoined,
      },
      message: "Account registered successfully",
    });

    response.cookies.set("clubpulse_user_id", newUser.id, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("clubpulse_session_role", assignedRole, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    response.cookies.set("clubpulse_token", `token_${newUser.id}_${Date.now()}`, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error) {
    console.error("Auth register error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to register campus account" },
      { status: 500 }
    );
  }
}
