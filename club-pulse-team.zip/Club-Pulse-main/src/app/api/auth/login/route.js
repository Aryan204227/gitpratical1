import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { initialUsers } from "@/lib/seedData";

export async function POST(request) {
  try {
    const body = await request.json();
    const { email, password, requestedRole } = body;

    // Standard credential authentication (no demo bypass)
    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: "Please enter your campus email and password." },
        { status: 400 }
      );
    }

    const normalizedEmail = email.trim().toLowerCase();
    const user =
      (typeof db?.getUserByEmail === "function"
        ? db.getUserByEmail(normalizedEmail)
        : null) ||
      (typeof db?.getUsers === "function"
        ? db.getUsers().find((u) => u.email?.toLowerCase() === normalizedEmail)
        : null) ||
      initialUsers.find((u) => u.email.toLowerCase() === normalizedEmail);

    if (!user) {
      return NextResponse.json(
        { success: false, error: "No registered campus account matches this email." },
        { status: 401 }
      );
    }

    // Exact password check:
    // If the account has a password property, match against it.
    // If it's an initial university seed account, default is "password123".
    const validPassword = user.password
      ? user.password === password
      : password === "password123";

    if (!validPassword) {
      return NextResponse.json(
        { success: false, error: "Invalid password. Please check your credentials." },
        { status: 401 }
      );
    }

    // Honor explicit role selection if chosen on the login UI
    let effectiveRole = requestedRole || user.role || "student";
    if (typeof db?.updateUser === "function" && user.id) {
      try {
        db.updateUser(user.id, { role: effectiveRole });
      } catch {}
    }

    const response = NextResponse.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: effectiveRole,
        avatar: user.avatar,
        department: user.department,
        year: user.year,
        bio: user.bio,
        clubsJoined: user.clubsJoined || [],
      },
      redirectUrl: effectiveRole === "admin" ? "/dashboard/admin" : "/dashboard/student",
      message: "Authentication successful",
    });

    response.cookies.set("clubpulse_user_id", user.id, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    response.cookies.set("clubpulse_session_role", effectiveRole, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    response.cookies.set("clubpulse_token", `token_${user.id}_${Date.now()}`, {
      path: "/",
      httpOnly: false,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    return response;
  } catch (error) {
    console.error("Auth login error:", error);
    return NextResponse.json(
      { success: false, error: "Internal server error during authentication" },
      { status: 500 }
    );
  }
}
