import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request, { params }) {
    try {
        const { id } = await params;
        const club = db.getClubById(id);
        if (!club) {
            return NextResponse.json({ success: false, error: "Club not found" }, { status: 404 });
        }
        const events = db.getEvents(club.id);
        const evidence = db.getEvidence(club.id);
        const memberships = db.getMemberships(club.id);
        return NextResponse.json({
            success: true,
            club,
            events,
            evidence,
            membersCount: memberships.length,
            leaders: memberships.filter((m) => m.clubRole !== "member"),
        });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch club details" }, { status: 500 });
    }
}
