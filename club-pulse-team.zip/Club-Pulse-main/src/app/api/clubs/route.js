import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const category = searchParams.get("category");
        const search = searchParams.get("search");
        const recruitment = searchParams.get("recruitment");
        let clubs = db.getClubs();
        if (category && category !== "All") {
            clubs = clubs.filter((c) => c.category.toLowerCase() === category.toLowerCase());
        }
        if (recruitment === "open") {
            clubs = clubs.filter((c) => c.recruitmentOpen);
        }
        if (search) {
            const q = search.toLowerCase();
            clubs = clubs.filter((c) => c.name.toLowerCase().includes(q) ||
                c.tagLine.toLowerCase().includes(q) ||
                c.description.toLowerCase().includes(q) ||
                c.category.toLowerCase().includes(q));
        }
        return NextResponse.json({ success: true, clubs });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch clubs" }, { status: 500 });
    }
}
