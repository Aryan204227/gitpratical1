import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const clubId = searchParams.get("clubId");
        const status = searchParams.get("status");
        const userId = searchParams.get("userId");
        let evidence = db.getEvidence();
        if (clubId) {
            evidence = evidence.filter((e) => e.clubId === clubId);
        }
        if (status) {
            evidence = evidence.filter((e) => e.status === status);
        }
        if (userId) {
            evidence = evidence.filter((e) => e.submittedBy === userId);
        }
        return NextResponse.json({ success: true, evidence });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch evidence" }, { status: 500 });
    }
}
export async function POST(request) {
    try {
        const body = await request.json();
        const { clubId, clubName, eventId, eventTitle, title, description, category, date, mediaUrls, reportUrl, attendanceCount, submittedBy, submittedByName, } = body;
        if (!clubId || !title || !description || !submittedBy) {
            return NextResponse.json({ success: false, error: "Missing required evidence fields" }, { status: 400 });
        }
        const newEvidence = db.createEvidence({
            clubId,
            clubName: clubName || "College Club",
            eventId,
            eventTitle,
            title,
            description,
            category: category || "Club Activity",
            date: date || new Date().toISOString().split("T")[0],
            mediaUrls: Array.isArray(mediaUrls) && mediaUrls.length > 0 ? mediaUrls : [
                "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800&auto=format&fit=crop&q=80"
            ],
            reportUrl,
            attendanceCount: Number(attendanceCount) || 0,
            submittedBy,
            submittedByName: submittedByName || "Club Organizer",
        });
        return NextResponse.json({ success: true, evidence: newEvidence });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to submit evidence" }, { status: 500 });
    }
}
export async function PATCH(request) {
    try {
        const body = await request.json();
        const { id, status, verifierId, verifierName, disputeReason } = body;
        if (!id || !status || (status !== "verified" && status !== "disputed")) {
            return NextResponse.json({ success: false, error: "Missing required verification status (verified or disputed)" }, { status: 400 });
        }
        const updated = db.verifyEvidence(id, status, verifierId || "admin-1", verifierName || "Platform Administrator", disputeReason);
        if (!updated) {
            return NextResponse.json({ success: false, error: "Evidence not found" }, { status: 404 });
        }
        return NextResponse.json({ success: true, evidence: updated });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to audit evidence" }, { status: 500 });
    }
}
