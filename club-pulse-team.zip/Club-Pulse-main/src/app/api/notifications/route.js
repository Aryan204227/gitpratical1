import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const userId = searchParams.get("userId");
        if (!userId) {
            return NextResponse.json({ success: false, error: "Missing userId" }, { status: 400 });
        }
        const notifications = db.getNotifications(userId);
        return NextResponse.json({ success: true, notifications });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch notifications" }, { status: 500 });
    }
}
export async function PATCH(request) {
    try {
        const body = await request.json();
        const { id, userId, markAll } = body;
        if (markAll && userId) {
            db.markAllNotificationsRead(userId);
            return NextResponse.json({ success: true, message: "All notifications marked as read." });
        }
        if (id) {
            db.markNotificationRead(id);
            return NextResponse.json({ success: true, message: "Notification marked as read." });
        }
        return NextResponse.json({ success: false, error: "Invalid parameters" }, { status: 400 });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to update notification" }, { status: 500 });
    }
}
