import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request, { params }) {
    try {
        const { id } = await params;
        const task = db.getTaskById(id);
        if (!task) {
            return NextResponse.json({ success: false, error: "Task not found" }, { status: 404 });
        }
        return NextResponse.json({ success: true, task });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch task" }, { status: 500 });
    }
}
export async function PATCH(request, { params }) {
    try {
        const { id } = await params;
        const body = await request.json();
        const updated = db.updateTask(id, body);
        if (!updated) {
            return NextResponse.json({ success: false, error: "Task not found" }, { status: 404 });
        }
        return NextResponse.json({ success: true, task: updated });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to update task" }, { status: 500 });
    }
}
// POST to delegate / reassign task
export async function POST(request, { params }) {
    try {
        const { id } = await params;
        const body = await request.json();
        const { newAssigneeId, newAssigneeName, delegatedByName } = body;
        if (!newAssigneeId || !newAssigneeName) {
            return NextResponse.json({ success: false, error: "Missing new assignee details" }, { status: 400 });
        }
        const task = db.delegateTask(id, newAssigneeId, newAssigneeName, delegatedByName || "Club Coordinator");
        if (!task) {
            return NextResponse.json({ success: false, error: "Task not found" }, { status: 404 });
        }
        return NextResponse.json({ success: true, task });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to delegate task" }, { status: 500 });
    }
}
