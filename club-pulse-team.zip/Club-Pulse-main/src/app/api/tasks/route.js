import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const clubId = searchParams.get("clubId");
        const assigneeId = searchParams.get("assigneeId");
        const status = searchParams.get("status");
        let tasks = db.getTasks();
        if (clubId) {
            tasks = tasks.filter((t) => t.clubId === clubId);
        }
        if (assigneeId) {
            tasks = tasks.filter((t) => t.assigneeId === assigneeId);
        }
        if (status) {
            tasks = tasks.filter((t) => t.status === status);
        }
        return NextResponse.json({ success: true, tasks });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch tasks" }, { status: 500 });
    }
}
export async function POST(request) {
    try {
        const body = await request.json();
        const { clubId, clubName, title, description, category, assigneeId, assigneeName, assigneeRole, assigneeAvatar, assignedById, assignedByName, priority, estimatedHours, dueDate, } = body;
        if (!clubId || !title || !assigneeId || !dueDate) {
            return NextResponse.json({ success: false, error: "Missing required task fields" }, { status: 400 });
        }
        const task = db.createTask({
            clubId,
            clubName: clubName || "College Club",
            title,
            description: description || "",
            category: category || "logistics",
            assigneeId,
            assigneeName: assigneeName || "Member",
            assigneeRole: assigneeRole || "Member",
            assigneeAvatar: assigneeAvatar || "",
            assignedById: assignedById || "leader",
            assignedByName: assignedByName || "Club President",
            priority: priority || "medium",
            estimatedHours: Number(estimatedHours) || 3,
            dueDate,
            status: "todo",
        });
        return NextResponse.json({ success: true, task });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to create task" }, { status: 500 });
    }
}
export async function PATCH(request) {
    try {
        const body = await request.json();
        const { id, ...updates } = body;
        if (!id) {
            return NextResponse.json({ success: false, error: "Missing task ID" }, { status: 400 });
        }
        const updated = db.updateTask(id, updates);
        if (!updated) {
            return NextResponse.json({ success: false, error: "Task not found" }, { status: 404 });
        }
        return NextResponse.json({ success: true, task: updated });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to update task" }, { status: 500 });
    }
}

