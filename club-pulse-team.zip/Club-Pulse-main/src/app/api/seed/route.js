import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function POST() {
    try {
        db.resetDatabase();
        return NextResponse.json({
            success: true,
            message: "Database successfully re-seeded with demo college clubs, members, tasks, and evidence.",
        });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to reset database" }, { status: 500 });
    }
}
