import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const clubId = searchParams.get("clubId");

    let events = db.getEvents();
    if (clubId) {
      events = events.filter((e) => e.clubId === clubId);
    }
    return NextResponse.json({ success: true, events });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: "Failed to fetch events" },
      { status: 500 }
    );
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const { action, eventId, userId, userName } = body;

    // Handle RSVP action
    if (action === "rsvp" && eventId) {
      const store = db.loadStore ? db.loadStore() : null;
      let events = db.getEvents();
      const event = events.find((e) => e.id === eventId);
      if (!event) {
        return NextResponse.json({ success: false, error: "Event not found" }, { status: 404 });
      }

      if (!event.attendeesList) {
        event.attendeesList = [];
      }

      const alreadyRsvp = event.attendeesList.some((a) => a.userId === userId);
      if (alreadyRsvp) {
        event.attendeesList = event.attendeesList.filter((a) => a.userId !== userId);
        if (event.actualAttendees && event.actualAttendees > 0) {
          event.actualAttendees -= 1;
        }
      } else {
        event.attendeesList.push({
          userId: userId || "guest",
          userName: userName || "Student",
          rsvpAt: new Date().toISOString(),
        });
        event.actualAttendees = (event.actualAttendees || 0) + 1;
      }

      return NextResponse.json({
        success: true,
        event,
        isRsvped: !alreadyRsvp,
        message: alreadyRsvp ? "RSVP cancelled." : "RSVP confirmed! See you there.",
      });
    }

    const newEvent = db.createEvent(body);
    return NextResponse.json({ success: true, event: newEvent });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error.message || "Failed to process event" },
      { status: 500 }
    );
  }
}
