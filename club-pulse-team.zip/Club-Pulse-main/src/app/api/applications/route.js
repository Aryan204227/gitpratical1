import { NextResponse } from "next/server";
import { db } from "@/lib/db";
export async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const clubId = searchParams.get("clubId");
        const userId = searchParams.get("userId");
        let applications = db.getApplications();
        if (clubId) {
            applications = applications.filter((a) => a.clubId === clubId);
        }
        if (userId) {
            applications = applications.filter((a) => a.userId === userId);
        }
        return NextResponse.json({ success: true, applications });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to fetch applications" }, { status: 500 });
    }
}
export async function POST(request) {
    try {
        const body = await request.json();
        const { userId, clubId, clubName, applicantName, applicantEmail, applicantAvatar, department, year, reason, skills, weeklyHoursAvailable, } = body;
        if (!userId || !clubId || !reason || !weeklyHoursAvailable) {
            return NextResponse.json({ success: false, error: "Missing required application fields" }, { status: 400 });
        }
        // Check if already applied
        const existingApps = db.getApplications(clubId);
        const duplicate = existingApps.find((a) => a.userId === userId && (a.status === "pending" || a.status === "under_review"));
        if (duplicate) {
            duplicate.reason = reason;
            duplicate.skills = Array.isArray(skills) ? skills : [skills];
            duplicate.weeklyHoursAvailable = Number(weeklyHoursAvailable);
            duplicate.updatedAt = new Date().toISOString();
            return NextResponse.json({ success: true, application: duplicate, updated: true });
        }
        const application = db.createApplication({
            userId,
            clubId,
            clubName: clubName || "College Club",
            applicantName: applicantName || "Student Applicant",
            applicantEmail: applicantEmail || "student@campus.edu",
            applicantAvatar: applicantAvatar || "",
            department: department || "General Engineering",
            year: year || "1st Year",
            reason,
            skills: Array.isArray(skills) ? skills : [skills],
            weeklyHoursAvailable: Number(weeklyHoursAvailable),
        });
        return NextResponse.json({ success: true, application });
    }
    catch (error) {
        console.error("POST /api/applications error:", error);
        return NextResponse.json({ success: false, error: error.message || "Failed to submit application" }, { status: 500 });
    }
}
export async function PATCH(request) {
    try {
        const body = await request.json();
        const { id, status, reviewerNotes, reviewerId, reviewerName } = body;
        if (!id || !status) {
            return NextResponse.json({ success: false, error: "Missing id or status" }, { status: 400 });
        }
        const updated = db.updateApplicationStatus(id, status, reviewerNotes || "", reviewerId || "current-leader", reviewerName || "Club Leader");
        if (!updated) {
            return NextResponse.json({ success: false, error: "Application not found" }, { status: 404 });
        }
        return NextResponse.json({ success: true, application: updated });
    }
    catch (error) {
        return NextResponse.json({ success: false, error: "Failed to update application" }, { status: 500 });
    }
}
