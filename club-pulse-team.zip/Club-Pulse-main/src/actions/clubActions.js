"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";

// Unit III: Form Validation Schema with Zod
const ApplicationSchema = z.object({
  clubId: z.string().min(1, "Club ID is required"),
  clubName: z.string().min(1, "Club name is required"),
  studentName: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid university email address"),
  declaredHours: z.coerce.number().min(1, "Must commit at least 1 hour/week").max(20, "Maximum 20 hours/week to avoid academic burnout"),
  motivation: z.string().min(10, "Please provide at least 10 characters explaining your interest"),
});

const TaskStatusSchema = z.object({
  taskId: z.string().min(1, "Task ID is required"),
  completed: z.boolean(),
});

const AcademicBreakSchema = z.object({
  studentId: z.string().min(1, "Student ID is required"),
  reason: z.string().min(5, "Please state reason (e.g. Midterm Exams, Capstone Project)"),
  returnDate: z.string().min(1, "Expected return date is required"),
});

/**
 * Server Action: Submit Club Recruitment Application
 * Syllabus: Unit III - Server Actions, Form Handling, Form Validation, Data Mutations
 */
export async function submitClubApplication(prevState, formData) {
  try {
    const rawData = {
      clubId: formData.get("clubId"),
      clubName: formData.get("clubName"),
      studentName: formData.get("studentName"),
      email: formData.get("email"),
      declaredHours: formData.get("declaredHours"),
      motivation: formData.get("motivation"),
    };

    const validated = ApplicationSchema.parse(rawData);

    // Perform database mutation / local store update
    const application = {
      id: `app_${Date.now()}`,
      ...validated,
      status: "pending",
      submittedAt: new Date().toISOString(),
    };

    // Revalidate paths per Unit II & Unit III specifications
    revalidatePath("/clubs");
    revalidatePath("/dashboard/student");
    revalidatePath("/dashboard/leader");

    return {
      success: true,
      message: `Application to ${validated.clubName} submitted successfully! Your workload is calibrated to ${validated.declaredHours}h/week.`,
      data: application,
    };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        errors: error.flatten().fieldErrors,
        message: "Validation failed. Please correct the fields.",
      };
    }
    return {
      success: false,
      message: error?.message || "Failed to submit application. Server action encountered an error.",
    };
  }
}

/**
 * Server Action: Toggle Task Completion (Supports Optimistic UI Updates)
 * Syllabus: Unit III - Server Actions, Data Mutations, Optimistic UI Updates
 */
export async function toggleTaskStatus(taskId, completed) {
  try {
    const validated = TaskStatusSchema.parse({ taskId, completed });

    // Revalidate affected paths
    revalidatePath("/dashboard/student");
    revalidatePath("/my-activity");

    return {
      success: true,
      taskId: validated.taskId,
      completed: validated.completed,
      updatedAt: new Date().toISOString(),
    };
  } catch (error) {
    return {
      success: false,
      message: error?.message || "Failed to update task status.",
    };
  }
}

/**
 * Server Action: Request Academic Leave of Absence
 * Syllabus: Unit III & IV - Student Welfare, Non-punitive Ghost Member Prevention
 */
export async function requestAcademicBreak(prevState, formData) {
  try {
    const rawData = {
      studentId: formData.get("studentId"),
      reason: formData.get("reason"),
      returnDate: formData.get("returnDate"),
    };

    const validated = AcademicBreakSchema.parse(rawData);

    revalidatePath("/dashboard/student");
    revalidatePath("/dashboard/leader");

    return {
      success: true,
      message: `Academic break registered through ${validated.returnDate}. You will not be marked inactive.`,
      data: validated,
    };
  } catch (error) {
    if (error instanceof z.ZodError) {
      return {
        success: false,
        errors: error.flatten().fieldErrors,
        message: "Please fill out all required break details.",
      };
    }
    return {
      success: false,
      message: "Server action failed to register academic break.",
    };
  }
}

