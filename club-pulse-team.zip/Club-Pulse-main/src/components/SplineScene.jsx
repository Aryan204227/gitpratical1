"use client";
import React, { useState } from "react";
import { Loader2 } from "lucide-react";

export default function SplineScene({
  url = "https://my.spline.design/untitled-5sS2LMXNYShHOCpiiXhjXcSJ/",
  height = "480px",
  title = "ClubPulse Interactive 3D Credential",
  subtitle = "Drag to rotate, pinch/scroll to inspect details",
  className = "",
}) {
  const [loading, setLoading] = useState(true);

  return (
    <div
      className={`relative w-full rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 dark:border-white/10 shadow-lg ${className}`}
      style={{ height }}
    >
      {loading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950 text-white gap-3 z-10">
          <Loader2 className="w-8 h-8 animate-spin text-orange-500" />
          <p className="text-xs font-semibold text-slate-300">Loading 3D Campus Credential...</p>
        </div>
      )}
      <iframe
        src={url}
        title={title}
        className="w-full h-full border-0"
        onLoad={() => setLoading(false)}
        allow="accelerometer; camera; gyroscope; microphone; xr-spatial-tracking"
      />
      {(title || subtitle) && (
        <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between pointer-events-none z-20">
          <div className="bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 text-white">
            {title && <p className="text-xs font-bold leading-tight">{title}</p>}
            {subtitle && <p className="text-[10px] text-slate-400 leading-tight">{subtitle}</p>}
          </div>
        </div>
      )}
    </div>
  );
}
