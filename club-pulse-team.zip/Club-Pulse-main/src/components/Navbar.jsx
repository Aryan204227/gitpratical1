"use client";
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  Bell,
  Search,
  LogOut,
  ChevronDown,
  Shield,
  GraduationCap,
  Sparkles,
  Zap,
} from "lucide-react";
import ThemeToggle from "@/components/ThemeToggle";

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const {
    currentUser,
    switchPersona,
    logout,
    notifications,
    unreadCount,
    markNotificationAsRead,
    markAllNotificationsAsRead,
  } = useAuth();

  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  if (!mounted) {
    return null;
  }

  // Hide Navbar completely on role selector / login, unauthorized, and Admin Dashboard (which has its own full sidebar)
  if (
    pathname === "/" ||
    pathname === "/login" ||
    pathname === "/signup" ||
    pathname === "/unauthorized" ||
    pathname.startsWith("/dashboard/admin") ||
    pathname.startsWith("/admin")
  ) {
    return null;
  }

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/clubs?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleSwitchToAdmin = async () => {
    try {
      await switchPersona("admin");
      router.push("/dashboard/admin");
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <header className="sticky top-0 z-40 h-[64px] bg-white/90 dark:bg-[#05020C]/90 backdrop-blur-xl border-b border-slate-200/90 dark:border-white/[0.08] shadow-xs transition-colors">
      <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Brand & Left Navigation */}
        <div className="flex items-center gap-6 lg:gap-8">
          <Link href="/dashboard/student" className="flex items-center gap-2.5 group">
            <div className="w-8 h-8 rounded-xl bg-[#F37021] dark:bg-gradient-to-tr dark:from-[#FF007F] dark:to-[#7B2CBF] flex items-center justify-center text-white shadow-xs group-hover:scale-105 transition-all dark:shadow-[0_0_15px_rgba(255,0,127,0.4)]">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white leading-none">
                Club<span className="text-[#F37021] dark:text-[#FF007F]">Pulse</span>
              </span>
            </div>
          </Link>

          {/* Live Campus Indicator */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-[#0E081A] border border-slate-200 dark:border-[#00F0FF]/30 text-[11px] font-mono text-slate-600 dark:text-[#00F0FF] shadow-2xs dark:shadow-[0_0_12px_rgba(0,240,255,0.2)]">
            <span className="w-2 h-2 rounded-full bg-[#F37021] dark:bg-[#00F0FF] animate-pulse" />
            <span className="font-semibold tracking-wider">LIVE PULSE</span>
          </div>

          <nav className="hidden md:flex items-center gap-1 text-[13px] font-medium text-slate-600 dark:text-slate-300">
            <Link
              href="/dashboard/student"
              className={`px-3 py-1.5 rounded-lg transition-all ${
                pathname === "/dashboard/student"
                  ? "bg-orange-50 dark:bg-white/[0.08] text-[#F37021] dark:text-[#FF007F] font-bold border border-orange-200 dark:border-[#FF007F]/40 shadow-xs dark:shadow-[0_0_12px_rgba(255,0,127,0.25)]"
                  : "hover:text-[#F37021] dark:hover:text-white hover:bg-orange-50/50 dark:hover:bg-white/5"
              }`}
            >
              Home
            </Link>
            <Link
              href="/clubs"
              className={`px-3 py-1.5 rounded-lg transition-all ${
                pathname.startsWith("/clubs")
                  ? "bg-orange-50 dark:bg-white/[0.08] text-[#F37021] dark:text-[#FF007F] font-bold border border-orange-200 dark:border-[#FF007F]/40 shadow-xs dark:shadow-[0_0_12px_rgba(255,0,127,0.25)]"
                  : "hover:text-[#F37021] dark:hover:text-white hover:bg-orange-50/50 dark:hover:bg-white/5"
              }`}
            >
              Clubs
            </Link>
            <Link
              href="/recruitment"
              className={`px-3 py-1.5 rounded-lg transition-all ${
                pathname === "/recruitment"
                  ? "bg-orange-50 dark:bg-white/[0.08] text-[#F37021] dark:text-[#FF007F] font-bold border border-orange-200 dark:border-[#FF007F]/40 shadow-xs dark:shadow-[0_0_12px_rgba(255,0,127,0.25)]"
                  : "hover:text-[#F37021] dark:hover:text-white hover:bg-orange-50/50 dark:hover:bg-white/5"
              }`}
            >
              Recruitment
            </Link>
            <Link
              href="/activity"
              className={`px-3 py-1.5 rounded-lg transition-all ${
                pathname === "/activity" || pathname === "/my-activity"
                  ? "bg-orange-50 dark:bg-white/[0.08] text-[#F37021] dark:text-[#FF007F] font-bold border border-orange-200 dark:border-[#FF007F]/40 shadow-xs dark:shadow-[0_0_12px_rgba(255,0,127,0.25)]"
                  : "hover:text-[#F37021] dark:hover:text-white hover:bg-orange-50/50 dark:hover:bg-white/5"
              }`}
            >
              My Activity
            </Link>
            <Link
              href="/about"
              className={`px-3 py-1.5 rounded-lg transition-all ${
                pathname === "/about" || pathname === "/transparency"
                  ? "bg-orange-50 dark:bg-white/[0.08] text-[#F37021] dark:text-[#FF007F] font-bold border border-orange-200 dark:border-[#FF007F]/40 shadow-xs dark:shadow-[0_0_12px_rgba(255,0,127,0.25)]"
                  : "hover:text-[#F37021] dark:hover:text-white hover:bg-orange-50/50 dark:hover:bg-white/5"
              }`}
            >
              About
            </Link>
          </nav>
        </div>

        {/* Search Bar & Right Actions */}
        <div className="flex items-center gap-3">
          {/* Search Input */}
          <form onSubmit={handleSearchSubmit} className="relative hidden sm:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search clubs, events..."
              className="w-44 lg:w-56 pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-[#0A0514] border border-slate-200 dark:border-white/[0.08] rounded-xl text-slate-800 dark:text-slate-200 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-[#F37021]/30 focus:border-[#F37021]/50 dark:focus:ring-[#00F0FF]/30 dark:focus:border-[#00F0FF]/50 transition-all"
            />
          </form>

          {/* Quick Switch to Dean/Admin Button */}
          <button
            type="button"
            onClick={handleSwitchToAdmin}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-purple-700 dark:text-[#E2E8F0] bg-purple-50 dark:bg-white/[0.06] hover:bg-purple-100 dark:hover:bg-[#FF007F]/20 border border-purple-200/80 dark:border-white/[0.1] hover:dark:border-[#FF007F]/50 rounded-xl transition-all shadow-2xs cursor-pointer"
            title="Switch to Admin / Dean Console"
          >
            <Shield className="h-3.5 w-3.5 text-purple-600 dark:text-[#FF007F]" />
            <span>Admin Console</span>
          </button>

          {/* Dark / Light Mode Toggle Button */}
          <ThemeToggle />

          {/* Notifications Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-xl text-slate-500 dark:text-slate-300 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Notifications"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-[#FF007F] ring-2 ring-white dark:ring-[#05020C] shadow-[0_0_8px_#FF007F]" />
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 rounded-2xl bg-white dark:bg-[#0E081A] border border-slate-200 dark:border-white/10 p-3 shadow-xl dark:shadow-[0_0_30px_rgba(0,0,0,0.8)] z-50 animate-in fade-in-50">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-white/10 text-xs">
                  <span className="font-bold text-slate-900 dark:text-white">Notifications</span>
                  {unreadCount > 0 && (
                    <button
                      onClick={markAllNotificationsAsRead}
                      className="text-[#F37021] dark:text-[#00F0FF] hover:underline text-[11px] font-medium cursor-pointer"
                    >
                      Mark all read
                    </button>
                  )}
                </div>
                <div className="mt-2 max-h-60 overflow-y-auto space-y-2 text-xs">
                  {notifications && notifications.length > 0 ? (
                    notifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => markNotificationAsRead(n.id)}
                        className={`p-2.5 rounded-xl cursor-pointer transition-colors ${
                          n.read
                            ? "bg-transparent text-slate-500 dark:text-slate-400"
                            : "bg-orange-50/70 dark:bg-white/5 text-slate-800 dark:text-white border-l-2 border-[#F37021] dark:border-[#FF007F]"
                        }`}
                      >
                        <p className="font-semibold text-xs">{n.title || n.message}</p>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5">
                          {n.timestamp ? new Date(n.timestamp).toLocaleTimeString() : "Just now"}
                        </p>
                      </div>
                    ))
                  ) : (
                    <p className="text-center py-4 text-slate-400 dark:text-slate-500 text-xs">
                      No new notifications
                    </p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* User Profile Pill (UMS Style) */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-white dark:bg-[#0E081A] hover:bg-slate-50 dark:hover:bg-white/10 transition-all border border-slate-300 dark:border-white/10 shadow-xs cursor-pointer"
            >
              <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-white/10 border border-slate-200 dark:border-white/20 flex items-center justify-center text-[11px] font-bold text-slate-700 dark:text-white overflow-hidden">
                {currentUser?.avatar ? (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span>👤</span>
                )}
              </div>
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                {currentUser?.name ? currentUser.name.split(" ")[0] : "User"}
              </span>
              <ChevronDown className="h-3 w-3 text-slate-400" />
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-52 rounded-2xl bg-white dark:bg-[#0E081A] border border-slate-200 dark:border-white/10 p-2 shadow-xl dark:shadow-[0_0_30px_rgba(0,0,0,0.8)] z-50">
                <div className="px-3 py-2 border-b border-slate-100 dark:border-white/10 mb-1">
                  <p className="text-xs font-bold text-slate-900 dark:text-white">{currentUser?.name || "Ayush"}</p>
                  <p className="text-[11px] text-slate-500 dark:text-[#00F0FF]">Student Account</p>
                </div>
                <Link
                  href="/dashboard/student"
                  onClick={() => setShowUserMenu(false)}
                  className="block px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-[#F37021] dark:hover:text-[#FF007F] hover:bg-orange-50 dark:hover:bg-white/5 rounded-lg transition-colors"
                >
                  My Dashboard
                </Link>
                <Link
                  href="/profile"
                  onClick={() => setShowUserMenu(false)}
                  className="block px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-[#F37021] dark:hover:text-[#FF007F] hover:bg-orange-50 dark:hover:bg-white/5 rounded-lg transition-colors"
                >
                  3D ID Card & Profile
                </Link>
                <Link
                  href="/activity"
                  onClick={() => setShowUserMenu(false)}
                  className="block px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-[#F37021] dark:hover:text-[#FF007F] hover:bg-orange-50 dark:hover:bg-white/5 rounded-lg transition-colors"
                >
                  My Activity & Proofs
                </Link>
                <button
                  type="button"
                  onClick={async () => {
                    setShowUserMenu(false);
                    await handleSwitchToAdmin();
                  }}
                  className="w-full text-left block px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:text-purple-600 dark:hover:text-[#FF007F] hover:bg-purple-50 dark:hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
                >
                  Switch to Admin / Dean
                </button>
                <Link
                  href="/"
                  onClick={() => setShowUserMenu(false)}
                  className="block px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-white/5 rounded-lg transition-colors"
                >
                  Role Selector
                </Link>
                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                    router.push("/");
                  }}
                  className="w-full text-left flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-lg transition-colors cursor-pointer"
                >
                  <LogOut className="h-3.5 w-3.5" />
                  <span>Log Out</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
